/**
 * ✏️ UBAH DI SINI: nama kantor, ruangan, agen, jadwal, dan data contoh.
 * Semua yang tampil di kantor diambil dari file ini. Nama dan angka di bawah fiktif.
 */

import laporanAgen from './laporan.json';

export const KANTOR = {
  nama: 'Roti Senja',
  /** Baris kecil di bawah nama (mis. nama perusahaan). */
  subjudul: 'Kantor AI · 2 lantai',
};

/** Nama tiap lantai (lantai 2 ditumpuk di atas lantai 1). */
export const LANTAI = [
  { no: 1, label: 'Operasional' },
  { no: 2, label: 'Tim ide' },
] as const;

/** Ruangan per lantai, dari kiri ke kanan. Lebarnya ikut `x0`–`x1` (meter, −7…7), lantainya `warna`, karpetnya `karpet`. */
export const RUANGAN = [
  { key: 'toko', label: 'Toko & kasir', lantai: 1, x0: -7, x1: 0.2, warna: '#8a5a3b', karpet: '#f2d7a7' },
  { key: 'dapur', label: 'Dapur & kas', lantai: 1, x0: 0.2, x1: 7, warna: '#d9c7ad', karpet: '#c9763a' },
  { key: 'ide', label: 'Ruang ide', lantai: 2, x0: -7, x1: 0.2, warna: '#9b6a45', karpet: '#e9b872' },
  { key: 'rapat', label: 'Ruang rapat', lantai: 2, x0: 0.2, x1: 7, warna: '#a8774f', karpet: '#7a4a2a' },
] as const;
export type RoomKey = (typeof RUANGAN)[number]['key'];

export interface Agen {
  key: string;
  nama: string;
  /** Tugasnya, satu baris. */
  tugas: string;
  ruang: RoomKey;
  /** 1 atau 2. */
  lantai: 1 | 2;
  /** Warna baju. */
  warna: string;
  /** Posisi meja di lantainya (x kiri–kanan −7…7, z belakang–depan −3…3). */
  x: number;
  z: number;
}

/** Sepuluh agen, lima per lantai (posisi meja jangan bertumpuk). */
export const AGEN: Agen[] = [
  { key: 'kasir', nama: 'Dina', tugas: 'Rekap penjualan', ruang: 'toko', lantai: 1, warna: '#e4572e', x: -5.3, z: -1.3 },
  { key: 'pesanan', nama: 'Rina', tugas: 'Daftar pesanan', ruang: 'toko', lantai: 1, warna: '#2a9d8f', x: -3.0, z: -1.3 },
  { key: 'cs', nama: 'Fajar', tugas: 'Draf balasan WA', ruang: 'toko', lantai: 1, warna: '#43aa8b', x: -4.2, z: 1.3 },
  { key: 'stok', nama: 'Bayu', tugas: 'Cek stok bahan', ruang: 'dapur', lantai: 1, warna: '#f2b134', x: 3.4, z: -1.3 },
  { key: 'keuangan', nama: 'Sari', tugas: 'Jumlah transaksi', ruang: 'dapur', lantai: 1, warna: '#ff5d8f', x: 5.3, z: 1.0 },
  { key: 'riset', nama: 'Raka', tugas: 'Ide produk', ruang: 'ide', lantai: 2, warna: '#3a86ff', x: -5.3, z: -1.3 },
  { key: 'konten', nama: 'Sekar', tugas: 'Caption IG', ruang: 'ide', lantai: 2, warna: '#c77dff', x: -3.0, z: -1.3 },
  { key: 'desain', nama: 'Lita', tugas: 'Brief poster', ruang: 'ide', lantai: 2, warna: '#ff8fab', x: -4.2, z: 1.3 },
  { key: 'laporan', nama: 'Doni', tugas: 'Laporan harian', ruang: 'rapat', lantai: 2, warna: '#577590', x: 3.4, z: -1.3 },
  { key: 'manajer', nama: 'Bu Ratna', tugas: 'Prioritas hari ini', ruang: 'rapat', lantai: 2, warna: '#8b5e34', x: 5.3, z: 1.0 },
];

export type Aktivitas = 'kerja' | 'laporan' | 'belajar';

const HK = [1, 2, 3, 4, 5];
/** Jadwal kerja (WIB). `agen: '*'` = semua agen. `hari` 1 = Senin … 7 = Minggu. `menit` = lama tampil. */
export const JADWAL: { agen: string[] | '*'; mulai: string; menit: number; hari: number[]; aktivitas: Aktivitas; label: string }[] = [
  { agen: ['kasir'], mulai: '07:32', menit: 75, hari: HK, aktivitas: 'kerja', label: 'rekap penjualan…' },
  { agen: ['stok'], mulai: '07:36', menit: 75, hari: HK, aktivitas: 'kerja', label: 'cek stok bahan…' },
  { agen: ['pesanan'], mulai: '07:40', menit: 75, hari: HK, aktivitas: 'kerja', label: 'urutkan pesanan…' },
  { agen: ['cs'], mulai: '07:44', menit: 75, hari: HK, aktivitas: 'kerja', label: 'draf balasan WA…' },
  { agen: ['keuangan'], mulai: '07:48', menit: 75, hari: HK, aktivitas: 'kerja', label: 'hitung transaksi…' },
  { agen: ['riset'], mulai: '07:54', menit: 60, hari: HK, aktivitas: 'kerja', label: 'cari ide produk…' },
  { agen: ['konten'], mulai: '07:58', menit: 60, hari: HK, aktivitas: 'kerja', label: 'tulis caption IG…' },
  { agen: ['desain'], mulai: '08:02', menit: 60, hari: HK, aktivitas: 'kerja', label: 'susun brief poster…' },
  { agen: ['laporan'], mulai: '08:06', menit: 60, hari: HK, aktivitas: 'kerja', label: 'gabung laporan…' },
  { agen: ['manajer'], mulai: '08:10', menit: 60, hari: HK, aktivitas: 'kerja', label: 'atur prioritas…' },
  { agen: '*', mulai: '15:42', menit: 25, hari: HK, aktivitas: 'laporan', label: 'menulis laporan harian…' },
  { agen: '*', mulai: '20:00', menit: 120, hari: [1, 2, 3, 4, 5, 6, 7], aktivitas: 'belajar', label: 'belajar malam…' },
];

/** Jam kantor: di luar jadwal, agen "siap menerima perintah" (atau ngopi, lihat papan, ngobrol). */
export const JAM_KANTOR = { buka: '07:30', tutup: '18:00' };

export interface Laporan {
  /** Ringkasan hari ini (gelembung di atas kepala). */
  ringkasan?: string;
  /** Butir yang menunggu keputusanmu (tanda "!" dan Mission Board). */
  menunggu?: string[];
  /** Butir mendesak (mejanya berkedip). */
  mendesak?: string[];
  /** Angka hari ini (Mission Board). Jangan isi nominal uang kalau videonya mau dibagikan. */
  angka?: { label: string; nilai: string }[];
}

/**
 * Laporan hari ini per agen. Ini data contoh; untuk data asli, isi dari API/JSON agenmu (lihat README, "Sambungkan agen
 * asli").
 */
export const LAPORAN: Record<string, Laporan> = laporanAgen;

/** Timelapse: satu hari dalam tiga babak (detik = lama tiap babak di video). */
export const BABAK = [
  { dari: '07:28', sampai: '08:44', detik: 12, judul: 'Pagi · 10 agent mulai kerja' },
  { dari: '15:36', sampai: '16:10', detik: 9, judul: 'Sore · laporan harian' },
  { dari: '19:52', sampai: '20:26', detik: 9, judul: 'Malam · belajar' },
];
