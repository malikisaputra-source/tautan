# Catatan lisensi VoxCPM2

Skill ini **tidak menyertakan** model VoxCPM2. Model dan pustaka `voxcpm` diunduh langsung dari sumber resminya saat dipasang:

- Repo: https://github.com/OpenBMB/VoxCPM
- Model: https://huggingface.co/openbmb/VoxCPM2
- Lisensi: **Apache License 2.0**, © OpenBMB. Teks lengkapnya ada di repo resmi di atas.

Lisensi Apache-2.0 berlaku untuk VoxCPM2. Skill buatan Maliki Studio (SKILL.md, suara.py, README, contoh) memakai Lisensi Nonkomersial Maliki Studio 1.0 (lihat `LICENSE`).

Pakai hanya untuk suaramu sendiri atau suara orang yang sudah memberi izin.
