import Vision
import CoreImage
let a=CommandLine.arguments; let ci=CIImage(contentsOf:URL(fileURLWithPath:a[1]))!
let h=VNImageRequestHandler(ciImage:ci); let ctx=CIContext()
let rq=VNGenerateForegroundInstanceMaskRequest(); try! h.perform([rq])
guard let r=rq.results?.first else { print(0); exit(0) }
var n=0
for idx in r.allInstances {
  let buf=try! r.generateMaskedImage(ofInstances:IndexSet(integer:idx), from:h, croppedToInstancesExtent:true)
  try! ctx.writePNGRepresentation(of:CIImage(cvPixelBuffer:buf), to:URL(fileURLWithPath:"\(a[2])-\(n).png"), format:CIFormat.RGBA8, colorSpace:CGColorSpace(name:CGColorSpace.sRGB)!)
  n+=1
}
print(n)
