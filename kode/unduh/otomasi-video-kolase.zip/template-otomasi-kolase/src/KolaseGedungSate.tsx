// Kolase · Gedung Sate (10 Nov 2026). Pola acuan reel gaya "Vox" (kolase kertas): latar koran gelap, judul serif
// raksasa di belakang objek, kertas langit sobek, objek potong masuk-keluar, latar disapu biru, 2.5D parallax,
// stiker berbayang, tangan ukiran + lingkaran kuning, teks kecil kapital di tengah. Tanpa logo/nama "Vox".
// Gambar: Gemini (milik Maliki), dipotong Vision macOS. Naskah: naskah/kolase-ai-01.txt. VO suara Maliki.
import React from "react";
import { AbsoluteFill, Audio, Easing, Img, interpolate, Sequence, spring, staticFile, useCurrentFrame } from "remotion";
import { loadFont as muatSerif } from "@remotion/google-fonts/PlayfairDisplay";
import { loadFont as muatInter } from "@remotion/google-fonts/Inter";
import waktu from "./waktu.json";

// ---- suara ----
// VO tidak disertakan. Simpan VO-mu di public/vo.mp3 lalu ubah PAKAI_VO = true.
// Waktu tiap adegan = nilai `t` di daftar ADEGAN; teks kecil di tengah dibaca dari src/waktu.json (sub).
const PAKAI_VO = false;
const MUSIK = "sfx/musik-v3-4-sinematik.mp3";
const Sfx: React.FC<{ nama: string; f: number; vol?: number }> = ({ nama, f, vol = 0.3 }) => (
  <Sequence from={f} layout="none"><Audio src={staticFile(`sfx/${nama}.mp3`)} volume={vol} /></Sequence>
);

const SERIF = muatSerif("normal", { weights: ["900"] }).fontFamily;
const SERIF_I = muatSerif("italic", { weights: ["900"] }).fontFamily;
const INTER = muatInter("normal", { weights: ["800"] }).fontFamily;
const FPS = 30;
const KUNING = "#f4b81c", KREM = "#efe7d6", MERAH = "#c8321f", BIRU = "#2f7fd6";
const F = (n: string) => staticFile(`kolase/${n}`);
const s2f = (s: number) => Math.round(s * FPS);
const E = Easing.bezier(0.22, 1, 0.36, 1);
const k = (f: number, a: number, b: number, d: number[], ease = E) =>
  interpolate(f, [a, b], d, { easing: ease, extrapolateLeft: "clamp", extrapolateRight: "clamp" });
const sp = (f: number, d: number, c = { damping: 13, stiffness: 140 }) => spring({ frame: f - d, fps: FPS, config: c });

export const DURASI_KOLASE = Math.ceil((waktu.durasi + 1.0) * FPS);

// tepi sobek: poligon bergerigi deterministik
const sobek = (atas: number, bawah: number, seed = 1) => {
  const n = 28, r = (i: number) => (Math.sin(i * 12.9898 + seed * 78.233) * 43758.5453) % 1;
  const a = Array.from({ length: n + 1 }, (_, i) => `${(i / n) * 100}% ${atas + Math.abs(r(i)) * 3}%`);
  const b = Array.from({ length: n + 1 }, (_, i) => `${100 - (i / n) * 100}% ${bawah - Math.abs(r(i + 50)) * 3}%`);
  return `polygon(${[...a, ...b].join(",")})`;
};

const Butir: React.FC = () => {
  const f = useCurrentFrame();
  return <AbsoluteFill style={{ pointerEvents: "none", opacity: 0.22, mixBlendMode: "overlay", backgroundImage: "radial-gradient(rgba(255,255,255,0.9) 0.7px, transparent 0.9px)", backgroundSize: "3px 3px", transform: `translate(${(f * 7) % 3}px, ${(f * 13) % 3}px)` }} />;
};
const Kertas: React.FC<{ warna: string }> = ({ warna }) => (
  <AbsoluteFill style={{ background: warna }}>
    <AbsoluteFill style={{ opacity: 0.35, mixBlendMode: "multiply", backgroundImage: "repeating-linear-gradient(17deg, rgba(0,0,0,0.05) 0 2px, transparent 2px 6px), radial-gradient(circle at 30% 20%, rgba(255,255,255,0.4), transparent 60%)" }} />
  </AbsoluteFill>
);

// judul serif raksasa (dipakai di BELAKANG objek)
const JudulBesar: React.FC<{ teks: string; f: number; d: number; y: number; ukuran?: number; warna?: string; miring?: number }> = ({ teks, f, d, y, ukuran = 330, warna = KREM, miring = -4 }) => (
  <div style={{ position: "absolute", left: 0, width: 1080, top: y, textAlign: "center", whiteSpace: "nowrap", fontFamily: SERIF, fontWeight: 900, fontSize: ukuran, lineHeight: 0.9, color: warna, letterSpacing: -8, textShadow: "-3px 0 0 rgba(230,40,40,0.35), 3px 0 0 rgba(40,120,230,0.35), 0 8px 0 rgba(0,0,0,0.15)" }}>
    {teks.split("").map((h, i) => {
      const s = sp(f - (f % 2), d + i * 3, { damping: 12, stiffness: 170 });
      return <span key={i} style={{ display: "inline-block", fontWeight: 900, fontFamily: i === teks.length - 1 && /[a-z]/.test(h) ? SERIF_I : SERIF, transform: `translateY(${(1 - s) * 120}px) rotate(${(1 - s) * miring * 3}deg)`, opacity: Math.min(1, s * 1.5) }}>{h === " " ? " " : h}</span>;
    })}
  </div>
);

// teks kecil kapital di tengah (pola acuan)
const Teks: React.FC = () => {
  const f = useCurrentFrame(); const t = f / FPS;
  const s = waktu.sub.find((x) => t >= x.t0 - 0.05 && t < x.t1 + 0.15);
  if (!s) return null;
  const w = s.kata.filter((x) => t >= x.t - 0.05).slice(-3).map((x) => x.k).join(" ");
  return (
    <div style={{ position: "absolute", left: 100, width: 880, top: 1380, textAlign: "center" }}>
      <span style={{ fontFamily: INTER, fontWeight: 800, fontSize: 46, letterSpacing: 1, color: "#fff", textTransform: "uppercase", textShadow: "0 2px 0 #000, 0 0 18px rgba(0,0,0,0.85)", WebkitTextStroke: "1.5px rgba(0,0,0,0.6)" }}>{w}</span>
    </div>
  );
};

// objek digunting dari majalah: tepi kertas putih tebal + bayangan lembut + cetak halftone
const TEPI = "drop-shadow(5px 0 0 #fbf8f1) drop-shadow(-5px 0 0 #fbf8f1) drop-shadow(0 5px 0 #fbf8f1) drop-shadow(0 -5px 0 #fbf8f1) drop-shadow(0 16px 18px rgba(0,0,0,0.4))";
const Objek: React.FC<{ src: string; x: number; y: number; w: number; f: number; d: number; dari?: "bawah" | "kiri" | "kanan" | "atas"; rot?: number; bayang?: boolean; out?: number; tepi?: boolean }> = ({ src, x, y, w, f, d, dari = "bawah", rot = 0, bayang = true, out, tepi = true }) => {
  const s = sp(f, d);
  const o = out !== undefined ? k(f, out, out + 12, [0, 1], Easing.in(Easing.cubic)) : 0;
  const dx = dari === "kiri" ? -1 : dari === "kanan" ? 1 : 0, dy = dari === "bawah" ? 1 : dari === "atas" ? -1 : 0;
  const goyang = Math.sin((f + x) / 40) * 1.2;
  return (
    <div style={{ position: "absolute", left: x, top: y, width: w, transform: `translate(${(1 - s) * dx * 1100 + o * 1200}px, ${(1 - s) * dy * 1400}px) rotate(${rot + goyang + (1 - s) * 8}deg)`, filter: bayang ? (tepi ? TEPI : "drop-shadow(0 18px 22px rgba(0,0,0,0.45))") : undefined }}>
      <Img src={F(src)} style={{ width: "100%", display: "block", filter: "contrast(1.12) saturate(0.85) sepia(0.12)" }} />
      <div style={{ position: "absolute", inset: 0, WebkitMaskImage: `url(${F(src)})`, maskImage: `url(${F(src)})`, WebkitMaskSize: "100% 100%", maskSize: "100% 100%", backgroundImage: "radial-gradient(rgba(0,0,0,0.55) 1.1px, transparent 1.5px)", backgroundSize: "5px 5px", mixBlendMode: "multiply", opacity: 0.35 }} />
    </div>
  );
};

// anotasi tangan: lingkaran, panah, garis bawah stabilo (tergambar seperti pena)
const Coret: React.FC<{ f: number; d: number; jenis: "lingkar" | "panah" | "garis"; x: number; y: number; w: number; h: number; warna?: string; rot?: number }> = ({ f, d, jenis, x, y, w, h, warna = "#f2c400", rot = 0 }) => {
  const p = k(f, d, d + 14, [1, 0], Easing.out(Easing.quad));
  const path = jenis === "lingkar" ? `M ${w * 0.5} 6 C ${w * 1.05} 4, ${w * 1.02} ${h - 4}, ${w * 0.5} ${h - 6} C ${-w * 0.04} ${h - 8}, ${-w * 0.02} 8, ${w * 0.62} 14`
    : jenis === "panah" ? `M 6 ${h - 6} C ${w * 0.3} ${h * 0.4}, ${w * 0.6} ${h * 0.2}, ${w - 10} 10 M ${w - 60} 6 L ${w - 8} 10 L ${w - 26} 58`
    : `M 4 ${h / 2} C ${w * 0.3} ${h / 2 - 6}, ${w * 0.7} ${h / 2 + 6}, ${w - 4} ${h / 2 - 2}`;
  return (
    <svg width={w} height={h} style={{ position: "absolute", left: x, top: y, overflow: "visible", transform: `rotate(${rot}deg)` }}>
      <path d={path} fill="none" stroke={warna} strokeWidth={jenis === "garis" ? h * 0.8 : 9} strokeLinecap="round" strokeLinejoin="round" opacity={jenis === "garis" ? 0.6 : 1}
        style={{ mixBlendMode: jenis === "garis" ? "multiply" : undefined }} pathLength={1} strokeDasharray={1} strokeDashoffset={p} />
    </svg>
  );
};

// sobekan kertas kecil melayang (lapisan depan)
const Serpih: React.FC<{ f: number }> = ({ f }) => (
  <AbsoluteFill style={{ pointerEvents: "none" }}>
    {Array.from({ length: 7 }).map((_, i) => {
      const x = (i * 211 + f * (0.6 + i * 0.15)) % 1300 - 120, y = (i * 389) % 1800 + Math.sin(f / 30 + i) * 30;
      return <div key={i} style={{ position: "absolute", left: x, top: y, width: 60 + (i % 3) * 40, height: 30 + (i % 4) * 16, background: i % 2 ? "#efe7d6" : "#d8cdb6", clipPath: "polygon(0 12%, 18% 0, 40% 10%, 63% 2%, 100% 14%, 92% 60%, 100% 100%, 70% 88%, 40% 100%, 12% 86%, 0 100%)", transform: `rotate(${f * (i % 2 ? 0.4 : -0.3) + i * 40}deg)`, boxShadow: "0 6px 10px rgba(0,0,0,0.3)", opacity: 0.85 }} />;
    })}
  </AbsoluteFill>
);

const Burung: React.FC<{ f: number; n?: number }> = ({ f, n = 6 }) => (
  <>{Array.from({ length: n }).map((_, i) => {
    const x = ((i * 173 + f * (2.2 + (i % 3) * 0.6)) % 1400) - 160, y = 420 + ((i * 97) % 380) + Math.sin(f / 9 + i) * 18;
    return <Img key={i} src={F("stk-4.png")} style={{ position: "absolute", left: x, top: y, width: 70 + (i % 3) * 22, transform: `rotate(${Math.sin(f / 7 + i) * 8}deg) scaleY(${0.8 + Math.abs(Math.sin(f / 4 + i)) * 0.25})`, filter: "grayscale(0.3) drop-shadow(0 6px 6px rgba(0,0,0,0.3))" }} />;
  })}</>
);

type Adegan = { t: number; isi: (f: number, l: number) => React.ReactNode };
const ADEGAN: Adegan[] = [
  // 1 · koran gelap → judul → kertas langit sobek → gedung naik + burung
  { t: 0, isi: (f) => (<>
      <Img src={F("koran.jpg")} style={{ position: "absolute", width: "100%", height: "100%", objectFit: "cover", filter: "brightness(0.55) contrast(1.1)" }} />
      <JudulBesar teks="SATE?" f={f} d={2} y={170} ukuran={250} />
      <AbsoluteFill style={{ clipPath: sobek(28, 28 + k(f, 10, 30, [0, 42]), 3) }}>
        <Img src={F("langit.jpg")} style={{ position: "absolute", left: -260, top: 120, width: 1600, transform: `scale(${1.15 + f * 0.0015})` }} />
        <Burung f={f} />
      </AbsoluteFill>
      <Objek src="gedungsate-pot.png" x={-80} y={200} w={1240} f={f} d={26} />
      <Coret f={f} d={s2f(3.4)} jenis="panah" x={650} y={420} w={230} h={170} warna="#ffffff" rot={180} />
      <Coret f={f} d={s2f(3.4)} jenis="lingkar" x={500} y={425} w={124} h={235} warna="#f2c400" />
    </>) },
  // 2 · latar disapu biru, arsitek ukiran + cetak biru, tanggal serif
  { t: 5.74, isi: (f) => {
      const sapu = k(f, 0, 18, [0, 100], Easing.inOut(Easing.cubic));
      return (<>
        <Img src={F("koran.jpg")} style={{ position: "absolute", width: "100%", height: "100%", objectFit: "cover", filter: "brightness(0.55)" }} />
        <AbsoluteFill style={{ clipPath: `polygon(0 0, ${sapu}% 0, ${sapu - 8}% 100%, 0 100%)` }}><Kertas warna={BIRU} /></AbsoluteFill>
        <JudulBesar teks="1920" f={f} d={s2f(1.4)} y={180} ukuran={360} />
        <Objek src="stk-7.png" x={420} y={640} w={560} f={f} d={14} dari="kanan" rot={8} />
        <Objek src="arsitek-pot.png" x={40} y={760} w={760} f={f} d={s2f(4.2)} dari="kiri" />
        <Coret f={f} d={s2f(1.7)} jenis="garis" x={100} y={615} w={240} h={50} />
        <div style={{ position: "absolute", left: 110, top: 610, fontFamily: SERIF_I, fontWeight: 900, fontSize: 64, color: KREM, opacity: k(f, s2f(1.6), s2f(2.2), [0, 1]) }}>27 Juli</div>
        <div style={{ position: "absolute", left: 600, top: 1210, background: "#fbf8f1", padding: "6px 14px", fontFamily: INTER, fontWeight: 800, fontSize: 30, color: "#1d1a14", transform: `rotate(-3deg) scale(${sp(f, s2f(4.5))})`, boxShadow: "0 6px 10px rgba(0,0,0,0.3)" }}>J. GERBER · ARSITEK</div>
        <Burung f={f + 200} n={3} />
      </>);
    } },
  // 3 · 2.5D: foto pembangunan dipecah lapisan, kamera maju
  { t: 12.54, isi: (f, l) => {
      const p = f / (l * FPS);
      return (<>
        <Kertas warna="#d9cdb4" />
        <AbsoluteFill style={{ perspective: 1200 }}>
          <Img src={F("bangun-bg.jpg")} style={{ position: "absolute", width: "100%", height: "100%", objectFit: "cover", transform: `translateZ(${-300 + p * 120}px) scale(1.35) translateX(${p * -30}px)`, filter: "sepia(0.4)" }} />
          <JudulBesar teks="HINDIA" f={f} d={6} y={160} ukuran={210} warna="#2b2418" />
          <Img src={F("bangun-fg.png")} style={{ position: "absolute", width: "100%", height: "100%", objectFit: "cover", transform: `translateZ(${p * 260}px) translateX(${p * 40}px)`, filter: "sepia(0.4) drop-shadow(0 20px 30px rgba(0,0,0,0.5))" }} />
        </AbsoluteFill>
        <AbsoluteFill style={{ clipPath: sobek(88, 120, 7), background: KREM }} />
        <Objek src="stk-5.png" x={680} y={1430} w={300} f={f} d={s2f(4.8)} rot={-8} />
        <Objek src="stk-0.png" x={90} y={1460} w={340} f={f} d={s2f(5.6)} rot={6} />
      </>);
    } },
  // 4 · puncak: zoom 2.5D ke tusuk sate, enam bulatan dihitung
  { t: 21.32, isi: (f) => {
      const z = k(f, 0, 80, [1, 1.35], Easing.inOut(Easing.cubic));
      return (<>
        <Kertas warna={BIRU} />
        <div style={{ position: "absolute", left: 140, top: 260, width: 800, height: 800, borderRadius: 400, background: KUNING, transform: `scale(${sp(f, 2)})` }} />
        <JudulBesar teks="SATE" f={f} d={s2f(3.3)} y={120} ukuran={340} />
        <div style={{ position: "absolute", left: 0, top: 0, width: 1080, height: 1920, transform: `scale(${z})`, transformOrigin: "540px 560px" }}>
          <Objek src="puncak-pot.png" x={90} y={180} w={900} f={f} d={0} />
          {[268, 342, 417, 500, 584, 676].map((cy, i) => {
            const d = s2f(1.5) + i * 4, s = sp(f, d, { damping: 10, stiffness: 220 });
            return <div key={i} style={{ position: "absolute", left: 540 - 50, top: cy - 38, width: 100, height: 76, borderRadius: 40, border: `6px solid ${MERAH}`, transform: `scale(${s}) rotate(${i * 7 - 15}deg)` }}>
              <span style={{ position: "absolute", left: 112, top: 2, fontWeight: 900, fontFamily: SERIF, fontSize: 52, color: "#fff", textShadow: "0 3px 0 rgba(0,0,0,0.4)", transform: `rotate(${15 - i * 7}deg)` }}>{i + 1}</span></div>;
          })}
        </div>
      </>);
    } },
  // 5 · "konon": lingkaran kuning, tangan ukiran menyangga uang & koin, angka gulden menghitung naik
  { t: 25.8, isi: (f) => {
      const n = Math.round(k(f, s2f(3.4), s2f(4.3), [0, 6000000], Easing.out(Easing.cubic)));
      return (<>
        <Kertas warna="#cfc8bb" />
        <Img src={F("koran.jpg")} style={{ position: "absolute", width: "100%", height: "100%", objectFit: "cover", opacity: 0.25, mixBlendMode: "multiply" }} />
        <div style={{ position: "absolute", left: 90, top: 380, width: 900, height: 900, borderRadius: 450, background: KUNING, transform: `scale(${sp(f, 0)})` }} />
        <JudulBesar teks="konon" f={f} d={2} y={140} ukuran={260} warna="#f4efe6" />
        <Objek src="tangan-pot.png" x={200} y={880} w={700} f={f} d={8} />
        <Objek src="stk-2.png" x={260} y={620} w={560} f={f} d={18} dari="atas" rot={-6} />
        <Objek src="stk-1.png" x={560} y={820} w={300} f={f} d={26} dari="atas" rot={10} />
        <Coret f={f} d={s2f(4.4)} jenis="lingkar" x={200} y={1215} w={680} h={150} warna={MERAH} />
        <div style={{ position: "absolute", left: 100, width: 880, top: 1240, textAlign: "center", opacity: k(f, s2f(3.3), s2f(3.6), [0, 1]) }}>
          <span style={{ display: "inline-block", background: "rgba(255,255,255,0.92)", padding: "14px 30px", borderRadius: 10, fontFamily: SERIF, fontWeight: 900, fontSize: 70, color: "#1d1a14", boxShadow: "0 10px 20px rgba(0,0,0,0.25)" }}>ƒ {n.toLocaleString("id-ID")}</span>
          <div style={{ margin: "10px auto 0", width: 600, height: 14, borderRadius: 7, background: "rgba(255,255,255,0.6)" }}><div style={{ width: `${(n / 6000000) * 100}%`, height: "100%", borderRadius: 7, background: "#2fae5a" }} /></div>
        </div>
      </>);
    } },
  // 6 · petir menyambar puncak
  { t: 31.56, isi: (f) => {
      const kilat = interpolate(f, [s2f(2.9), s2f(2.9) + 3, s2f(2.9) + 8, s2f(2.9) + 14], [0, 0.55, 0.25, 0], { extrapolateLeft: "clamp", extrapolateRight: "clamp" });
      return (<>
        <Kertas warna="#1d2533" />
        <Img src={F("koran.jpg")} style={{ position: "absolute", width: "100%", height: "100%", objectFit: "cover", opacity: 0.18, mixBlendMode: "screen" }} />
        <JudulBesar teks="PETIR" f={f} d={s2f(2.8)} y={150} ukuran={250} warna={KUNING} />
        <Objek src="puncak-pot.png" x={140} y={560} w={800} f={f} d={0} />
        <Objek src="stk-3.png" x={420} y={260} w={420} f={f} d={s2f(2.8)} dari="atas" rot={-10} />
        <div style={{ position: "absolute", left: 120, top: 760, background: "#fbf8f1", padding: "8px 16px", fontFamily: INTER, fontWeight: 800, fontSize: 32, color: "#1d1a14", transform: `rotate(-4deg) scale(${sp(f, s2f(1.2))})`, boxShadow: "0 6px 10px rgba(0,0,0,0.35)" }}>PENANGKAL PETIR</div>
        <Coret f={f} d={s2f(1.4)} jenis="panah" x={480} y={700} w={130} h={110} warna="#ffffff" />
        <AbsoluteFill style={{ background: "rgb(255,250,220)", mixBlendMode: "screen", opacity: kilat }} />
      </>);
    } },
  // 7 · 1945: tujuh siluet kertas, lingkaran merah, tanggal
  { t: 36.34, isi: (f) => (<>
      <Kertas warna={KREM} />
      <div style={{ position: "absolute", left: 190, top: 330, width: 700, height: 700, borderRadius: 350, background: MERAH, transform: `scale(${sp(f, 0)})` }} />
      <JudulBesar teks="1945" f={f} d={4} y={140} ukuran={360} warna="#1d1a14" />
      <Objek src="tjh-0.png" x={60} y={720} w={960} f={f} d={s2f(3.0)} bayang />
      <div style={{ position: "absolute", left: 120, top: 660, background: "#fbf8f1", padding: "6px 14px", fontFamily: INTER, fontWeight: 800, fontSize: 30, color: "#1d1a14", transform: `rotate(-5deg) scale(${sp(f, s2f(3.6))})`, boxShadow: "0 6px 10px rgba(0,0,0,0.3)" }}>7 PEGAWAI MUDA PU</div>
      <div style={{ position: "absolute", left: 100, width: 880, top: 520, textAlign: "center", fontFamily: SERIF_I, fontWeight: 900, fontSize: 60, color: "#1d1a14", opacity: k(f, s2f(1.0), s2f(1.5), [0, 1]) }}>3 Desember</div>
      <AbsoluteFill style={{ clipPath: sobek(82, 120, 11), background: "#1d1a14" }} />
    </>) },
  // 8 · Hari Bakti PU: gedung di telapak tangan, kertas biru
  { t: 44.9, isi: (f) => (<>
      <Kertas warna={BIRU} />
      <div style={{ position: "absolute", left: 140, top: 420, width: 800, height: 800, borderRadius: 400, background: KUNING, transform: `scale(${sp(f, 0)})` }} />
      <JudulBesar teks="BAKTI" f={f} d={3} y={160} ukuran={250} />
      <Objek src="tangan-pot.png" x={190} y={960} w={720} f={f} d={4} />
      <Objek src="gedungsate-pot.png" x={150} y={640} w={780} f={f} d={12} dari="atas" />
      <Objek src="stk-6.png" x={720} y={1520} w={240} f={f} d={s2f(2.4)} rot={-12} />
    </>) },
  // 9 · CTA: poster kolase dari semua stiker + GRATIS
  { t: 49.0, isi: (f) => {
      const st = [["stk-0.png", 60, 660, 320, -8], ["stk-5.png", 700, 620, 300, 7], ["stk-2.png", 300, 1060, 480, -4], ["stk-7.png", 640, 1000, 340, 9], ["stk-8.png", 80, 1180, 300, 12], ["stk-1.png", 760, 1300, 240, -6], ["stk-6.png", 380, 560, 260, 4]] as const;
      return (<>
        <Img src={F("koran.jpg")} style={{ position: "absolute", width: "100%", height: "100%", objectFit: "cover", filter: "brightness(0.5)" }} />
        <AbsoluteFill style={{ clipPath: sobek(30, 70, 5) }}><Img src={F("langit.jpg")} style={{ position: "absolute", left: -260, top: 300, width: 1600 }} /></AbsoluteFill>
        <JudulBesar teks="GRATIS" f={f} d={s2f(1.6)} y={160} ukuran={220} warna={KUNING} />
        {st.map(([s, x, y, w, r], i) => <Objek key={i} src={s} x={x} y={y} w={w} f={f} d={4 + i * 4} dari={i % 2 ? "kanan" : "kiri"} rot={r} />)}
        <Objek src="gedungsate-pot.png" x={140} y={760} w={800} f={f} d={30} />
        <div style={{ position: "absolute", left: 100, width: 880, top: 1640, textAlign: "center", transform: `scale(${sp(f, s2f(4.8))})` }}>
          <span style={{ display: "inline-block", background: "#fff", padding: "12px 28px", borderRadius: 12, fontFamily: INTER, fontWeight: 800, fontSize: 40, color: "#111" }}>TEMPLATE + PROMPT · LINK DI BIO</span>
        </div>
      </>);
    } },
];

const Bungkus: React.FC<{ a: Adegan; lama: number; i: number }> = ({ a, lama, i }) => {
  const f = useCurrentFrame(); const n = lama * FPS;
  const f15 = f - (f % 2); // grafik terasa "patah" 15 fps seperti Vox
  const masuk = i ? k(f, 0, 14, [1, 0], Easing.inOut(Easing.quad)) : 0;
  const drift = 1 + f * 0.0007;
  return (
    <AbsoluteFill style={{ overflow: "hidden", opacity: i ? k(f, 0, 14, [0.0001, 1], Easing.inOut(Easing.quad)) : 1 }}>
      <AbsoluteFill style={{ transform: `scale(${(1 + masuk * 0.18) * drift}) translate(${Math.sin(f / 60) * 6}px, ${Math.cos(f / 70) * 5}px)`, filter: `blur(${masuk * 14}px)` }}>{a.isi(f15, lama)}</AbsoluteFill>
      <Serpih f={f15 + i * 90} />
    </AbsoluteFill>
  );
};

// tekstur kertas "mendidih": berganti tiap 4 bingkai
const Mendidih: React.FC = () => {
  const f = useCurrentFrame(); const v = Math.floor(f / 4) % 3;
  return <AbsoluteFill style={{ pointerEvents: "none", mixBlendMode: "multiply", opacity: 0.28, backgroundImage: `url(${F("koran.jpg")})`, backgroundSize: v === 0 ? "1200px auto" : v === 1 ? "1400px auto" : "1100px auto", backgroundPosition: `${v * 137}px ${v * 211}px`, filter: "grayscale(1) contrast(0.6) brightness(1.6)" }} />;
};

export const KolaseGedungSate: React.FC = () => {
  const mulai = ADEGAN.map((a) => s2f(a.t));
  return (
    <AbsoluteFill style={{ background: "#111" }}>
      {ADEGAN.map((a, i) => {
        const dari = mulai[i], sampai = i + 1 < ADEGAN.length ? mulai[i + 1] + 15 : DURASI_KOLASE;
        return <Sequence key={i} from={dari} durationInFrames={sampai - dari}><Bungkus a={a} lama={(sampai - dari) / FPS} i={i} /></Sequence>;
      })}
      <Mendidih />
      <Butir />
      <AbsoluteFill style={{ pointerEvents: "none", background: "radial-gradient(ellipse at center, transparent 55%, rgba(0,0,0,0.45))" }} />
      <Teks />
      <div style={{ position: "absolute", right: 100, top: 1800, fontFamily: INTER, fontSize: 20, color: "rgba(255,255,255,0.7)" }}>ilustrasi AI · @malikisaputra</div>
      {PAKAI_VO && <Audio src={staticFile("vo.mp3")} />}
      <Audio src={staticFile(MUSIK)} volume={0.1} loop />
      {mulai.slice(1).map((m, i) => <Sfx key={i} nama="woosh" f={m - 3} vol={0.2} />)}
      <Sfx nama="kamera-shutter" f={s2f(31.56 + 2.9)} vol={0.4} />
    </AbsoluteFill>
  );
};
