---
name: kantor-ai-koperasi
description: Siapkan dan jalankan 15 AI agent untuk koperasi desa (contoh Koperasi Desa Merah Putih, 3 lantai) dari data koperasi sendiri, lalu tampilkan hasilnya di Kantor AI 3D. Pakai saat pengguna minta "kantor AI koperasi", "15 agent koperasi", "laporan harian koperasi", atau menyebut skill ini.
---

# Kantor AI Koperasi · 15 agent, 3 lantai

Template gratis dari Maliki Saputra (@malikisaputra). Semua aturan ada di `CLAUDE.md`; agent ada di `.claude/agents/`.

## Lantai dan agent
- Lantai 1 · layanan anggota: `sembako`, `stok`, `gudang`, `logistik`, `cs`
- Lantai 2 · keuangan & kesehatan: `simpanpinjam`, `anggota`, `klinik`, `apotek`, `pembukuan`
- Lantai 3 · pengurus: `harga`, `konten`, `desain`, `laporan`, `ketua`

## Alur
1. **Kenali koperasinya.** Tanyakan nama koperasi dan desa, unit usaha yang benar-benar ada, dan nama tiap petugas
   (boleh tetap memakai nama contoh). Unit yang tidak ada: hapus agentnya dari `.claude/agents/` dan dari `LANGKAH.md`.
2. **Siapkan data.** Cocokkan file pengguna dengan format di `data/` (lihat header CSV contoh). Jangan mengarang data
   yang tidak diberikan; kolom yang kosong tetap kosong. Pastikan tidak ada nominal uang.
3. **Sesuaikan aturan.** Ganti nama koperasi di `CLAUDE.md`. LARANGAN wajib dipertahankan: tidak menyetujui pinjaman,
   tidak mendiagnosis, tidak meresepkan obat, tidak mengirim pesan, tidak menambah janji atau klaim.
4. **Jalankan per lantai**, satu tahap per giliran, jangan 15 agent sekaligus:
   Tahap 1 (lantai 1) → Tahap 2 (lantai 2) → Tahap 3 (harga, konten, desain) → Tahap 4 (laporan, lalu ketua).
   Panggil subagent dengan alat Task. Setelah tiap tahap, cek file di `hasil/` ada dan angkanya cocok dengan data.
5. **Laporkan ke pengguna** dalam bahasa Indonesia santai: ringkasan per lantai, daftar "perlu keputusan pengurus",
   dan agent yang meleset (kalau ada). Ingatkan: AI hanya membuat draf, keputusan tetap di pengurus.
6. **Kantor 3D (opsional).** Salin `hasil/laporan.json` ke `src/laporan.json`. Ubah nama di `src/config.ts`
   (`KANTOR`, `AGEN`) bila petugas atau unit berbeda. Jalankan `npm install` lalu `npm run dev`;
   rekam video dengan `npm run rekam -- kantor.mp4` (butuh Chrome + ffmpeg).

## Catatan
- Data dan koperasi di template ini fiktif. Jangan memakai logo resmi Kopdes Merah Putih.
- Model gratis (OpenCode, `.opencode/agent/`) bisa dipakai, tapi bisa tiba-tiba tidak tersedia: jalankan per lantai
  dan siapkan model cadangan.
