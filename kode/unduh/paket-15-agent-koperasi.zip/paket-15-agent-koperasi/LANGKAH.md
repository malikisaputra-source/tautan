# Jalankan per tahap (satu perintah per tahap)
Tahap 1 · Lantai 1: panggil agent sembako, stok, gudang, logistik, cs.
Tahap 2 · Lantai 2: panggil agent simpanpinjam, anggota, klinik, apotek, pembukuan.
Tahap 3 · Lantai 3: panggil agent harga, konten, desain.
Tahap 4 · Rapat: panggil agent laporan, lalu agent ketua.
Tiap agent WAJIB menulis file hasil persis dengan nama yang disebut di tugasnya, plus hasil/laporan/<kunci>.json.
