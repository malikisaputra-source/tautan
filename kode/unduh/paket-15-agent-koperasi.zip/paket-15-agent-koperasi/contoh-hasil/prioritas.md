# Prioritas Minggu Ini · Koperasi Merah Putih Desa Sukamaju (fiktif)
Per 12 November 2026 · disusun oleh Bu Rahma (Lantai 3, Ketua)
Sumber: `hasil/laporan-mingguan.md`

## 5 prioritas minggu ini
1. **Putuskan materi promo paling lambat 13 Nov**
   - Draf pengumuman WA, 3 caption, dan poster (`hasil/poster.html`) masih menunggu persetujuan dan belum dikirim atau dicetak.
   - Promo mulai 14 Nov, senam sehat dan cek tensi Sabtu 15 Nov 07.00.
   - Yang perlu dipastikan dulu: syarat promo mi instan dan petugas cek tensi.
2. **Cek keamanan cold storage dan selisih cabai merah**
   - Suhu sempat 6.2 °C (12:00) dan 5.4 °C (16:00), di atas batas 0-5 °C; pukul 20:00 sudah 4.3 °C.
   - Periksa barang di dalam cold storage.
   - Cabai keluar 210 kg (gudang dan kasir T05), buku mencatat 200 kg. Ada selisih 10 kg, jadi bukti fisik perlu dicek.
3. **Pantau angsuran pinjaman yang terlambat dan jatuh tempo**
   - P05 (Pak Asep) terlambat sejak 5 Nov, P03 (Pak Ujang) jatuh tempo 15 Nov, P04 (Bu Sumi) jatuh tempo 17 Nov.
   - P01 (Pak Darto) dan P02 (Bu Neni) baru tahap verifikasi dan belum disetujui.
4. **Isi ulang stok sembako dan obat yang di bawah minimum**
   - Sembako: Telur 10 kg (min 25), Beras 5 kg 12 karung (min 20), Gula 1 kg 8 bungkus (min 15), Kopi 15 renceng (min 20).
   - Obat: Antasida 15 (min 50), Amoksisilin 30 (min 40), Parasetamol 40 (min 100).
   - Salep luka (stok 12) kedaluwarsa 30 Nov 2026. Antasida dan Amoksisilin kedaluwarsa Desember 2026.
5. **Rapikan catatan dan layani anggota**
   - Ada 2 selisih kasir vs buku: T03 parasetamol (10 vs 8 strip) dan T05 cabai (210 vs 200 kg).
   - Keluhan telur pecah 3 butir dari Bu Inah (A03).
   - 6 draf balasan WA belum terkirim.
   - 5 anggota belum bayar iuran wajib: 3 aktif (Bu Inah, Bu Lilis, Pak Asep) dan 2 baru (Pak Rudi, Bu Yati).

## Perlu keputusan pengurus
### Pinjaman (ketua tidak menyetujui di sini)
- Hasil verifikasi pengajuan P01 (Pak Darto) dan P02 (Bu Neni).
- Arahan untuk angsuran P05 (Pak Asep) yang terlambat sejak 5 Nov.
- Persiapan menghadapi jatuh tempo P03 (15 Nov) dan P04 (17 Nov).

### Keluhan dan layanan anggota
- Penggantian telur pecah untuk Bu Inah. Stok telur sedang di bawah minimum.
- Persetujuan 6 draf balasan WA sebelum dikirim petugas.
- Info jam buka, syarat simpan pinjam, dan syarat daftar anggota belum ada di data, jadi perlu ditetapkan pengurus.
- Pak Asep menanyakan syarat daftar anggota, padahal ia sudah anggota aktif. Ini perlu dikonfirmasi.

### Iuran anggota
- Tindak lanjut 5 anggota yang belum bayar iuran wajib.
- Apakah anggota baru wajib membayar iuran di bulan pendaftarannya.

### Stok, gudang, dan logistik
- Persetujuan usulan belanja: Telur 15 kg, Beras 8 karung, Gula 7 bungkus, Kopi 5 renceng.
- Pengadaan ulang Parasetamol, Antasida, dan Amoksisilin.
- Penanganan obat yang segera kedaluwarsa: Salep luka, Antasida, Amoksisilin.
- Pemeriksaan barang di cold storage dan tindak lanjut stok cabai merah.
- Penetapan jadwal, jam, dan petugas antar untuk 7 antaran ke 4 RT, termasuk pesanan Bu Sumi (cek apakah sama dengan A01).

### Pembukuan dan harga
- Koreksi buku untuk T03 dan T05 setelah bukti fisik dicek.
- Penyesuaian harga beli/jual Jagung (+9%), Gabah (+4%), dan Cabai merah (-13%).
- Cara menghitung peringkat produk terlaris, karena satuannya berbeda-beda.

### Promo dan kesehatan
- Persetujuan pengumuman WA, caption, dan poster, termasuk syarat promo mi instan dan petugas cek tensi.
- Tindak lanjut banyaknya kunjungan batuk pilek (9 dari 21). Keputusan medis tetap di tangan dokter.
- Pertanyaan obat maag dari Pak Ujang diteruskan ke petugas apotek/klinik, tanpa saran obat dari agent.
