# Rekap Keanggotaan · 12 November 2026
Sumber: `data/anggota.csv` (data fiktif). Disusun oleh Wati (Lantai 2, Keanggotaan).

## Ringkasan
- Total anggota tercatat: 9 orang
- Anggota aktif: 7 orang
- Anggota baru: 2 orang
- Iuran wajib bulan ini sudah masuk: 4 orang
- Iuran wajib bulan ini belum masuk: 5 orang

## Anggota baru
- M008 · Pak Rudi · daftar 10 Nov · iuran wajib bulan ini: belum
- M009 · Bu Yati · daftar 11 Nov · iuran wajib bulan ini: belum

## Iuran wajib bulan ini belum masuk
Anggota aktif:
- M003 · Bu Inah
- M005 · Bu Lilis
- M006 · Pak Asep

Anggota baru:
- M008 · Pak Rudi
- M009 · Bu Yati

## Iuran wajib bulan ini sudah masuk
- M001 · Bu Sumi
- M002 · Pak Darto
- M004 · Pak Ujang
- M007 · Bu Neni

## Menunggu keputusan pengurus
- Cara dan waktu menindaklanjuti 5 anggota yang iuran wajibnya belum masuk (tidak ada pesan yang dikirim oleh Wati).
- Apakah anggota baru (M008, M009) wajib membayar iuran wajib untuk bulan pendaftarannya; aturan ini tidak tercantum di data.
