# Skill: Clone Suara VoxCPM2 (gratis, lokal)

Skill AI agent untuk meng-clone **suaramu sendiri** dari rekaman 10–20 detik, lalu mengubah naskah jadi file suara (wav). Modelnya VoxCPM2 dari OpenBMB: berjalan di laptop, tanpa API, dan bisa berbahasa Indonesia.

## Isi
- `SKILL.md`: instruksi untuk AI agent (Claude Code, Codex, Gemini CLI, Antigravity)
- `suara.py`: skrip pembuat suara (sekali muat model untuk banyak kalimat; mode bawaan, desain suara, atau clone)
- `contoh/naskah.json`: contoh daftar kalimat
- `LICENSE`: Lisensi Nonkomersial Maliki Studio 1.0
- `NOTICE-VoxCPM.md`: catatan lisensi Apache-2.0 VoxCPM2

## Cara pakai
1. Ekstrak zip ini ke `.claude/skills/clone-suara-voxcpm/` di folder proyekmu. Untuk agent lain, pakai folder skill agent masing-masing.
2. Taruh rekamanmu (`rekaman.wav`, 10–20 detik) di folder proyek.
3. Buka agent di folder itu lalu ketik: **"pakai skill clone-suara-voxcpm, clone suaraku dari rekaman.wav lalu bacakan naskah ini: …"**

Mau tanpa agent? Jalankan sendiri:
```
uv venv --python 3.12
uv pip install voxcpm
uv run voxcpm clone --text "Halo, ini suara clone aku." --reference-audio rekaman.wav --output hasil.wav
```
Rekaman Voice Memos (.m4a) di Mac bisa diubah dulu ke wav: `afconvert -f WAVE -d LEI16 rekaman.m4a rekaman.wav`

Perlu sekitar 5 GB untuk model. Di Mac M-series, sekitar 1 detik proses menghasilkan 1 detik suara. Tanpa GPU, prosesnya lebih lambat.

## Etika
Clone hanya suaramu sendiri atau suara orang yang sudah memberi izin. Beri label "suara AI" saat mengunggah hasilnya.

---
<!-- kredit-maliki -->
**Kredit:** Template oleh Maliki Saputra (@malikisaputra) — https://malikisaputra.biz.id.
**Lisensi Nonkomersial Maliki Studio:** gratis untuk belajar & usaha/organisasi sendiri. Dilarang dijual, dijual ulang, atau dipakai untuk jasa berbayar. Kredit wajib dipertahankan. Lihat `LICENSE`. VoxCPM2 sendiri berlisensi Apache-2.0 (lihat `NOTICE-VoxCPM.md`).
