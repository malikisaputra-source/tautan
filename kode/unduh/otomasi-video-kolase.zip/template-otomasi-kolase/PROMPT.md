# Prompt gambar (Gemini) untuk video kolase gaya "Vox"

Tulis di Gemini (mode gambar), satu gambar per prompt. Ganti isi [ ] sesuai topikmu. Selalu cek hasil AI: jumlah detail (mis. bulatan tusuk sate), tanggal, tulisan aneh di uang/kertas.

1. **Objek utama terisolasi** — "foto realistis [Gedung Sate Bandung] dilihat dari depan, bangunan utuh, TERISOLASI di latar putih polos bersih, cahaya siang lembut, gaya foto arsip berwarna hangat. 9:16. Tanpa teks."
2. **Kertas langit sobek** — "selembar kertas disobek kasar berisi foto langit biru berawan vintage, tepi atas-bawah sobek putih bergerigi dengan serat kertas, di atas latar hitam polos. 9:16. Tanpa teks."
3. **Latar koran tua** — "tekstur kertas koran tua gelap, huruf serif kapital besar bahasa Belanda lama yang samar ([KATA, KOTA, TAHUN]), bertumpuk miring, noda, lipatan, film grain. Tanpa orang/logo. 9:16."
4. **Close-up detail kunci** — "close-up realistis [puncak gedung: tiang dengan enam bulatan], TERISOLASI di latar putih polos. 1:1. Tanpa teks."
5. **Tangan ukiran** — "ilustrasi engraving hitam-putih bergaris halus seperti uang kertas kuno, tangan terbuka menengadah dari bawah frame, telapak kosong, TERISOLASI di latar putih. 9:16."
6. **Lembar stiker 3x3** — "lembar stiker kolase 9 objek terpisah grid 3x3, latar putih: [uang kertas lama fiktif, koin, peta kota kuno, perangko fiktif, petir ilustrasi, dua merpati, cap stempel merah, tiket tua, cetak biru]. Foto realistis, bayangan tipis, tanpa teks terbaca. 1:1."
7. **Foto arsip untuk 2.5D** — "foto arsip hitam-putih sepia 1920-an, [pembangunan gedung kolonial dengan perancah bambu], pekerja kecil di kejauhan wajah tidak jelas, film grain. 9:16."
8. **Siluet kertas** — "[tujuh] siluet [pemuda 1945] dari kertas hitam digunting (paper cut-out), berbaris, latar krem polos. Tanpa wajah/teks. 9:16."
9. **Tokoh ukiran fiktif** — "ilustrasi engraving hitam-putih, [arsitek Eropa 1920-an fiktif] di meja gambar, setengah badan, TERISOLASI di latar putih."

Unduh lewat tombol "Download gambar ukuran penuh". Potong latar: `swiftc -O alat/potong.swift -o potong && ./potong in.jpg out.png` (satu objek) atau `alat/pisah.swift` (lembar stiker → satu PNG per objek). Untuk objek bertiang tipis di latar putih, potong pakai ambang warna putih supaya tiang tidak hilang.
