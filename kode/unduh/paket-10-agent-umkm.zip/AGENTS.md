# Kantor AI UMKM "Roti Senja" · aturan bersama 10 agent
- Bisnis contoh (fiktif): toko roti rumahan, kantor 2 lantai, 10 karyawan AI.
- Lantai 1 (operasional): kasir, stok, pesanan, cs, keuangan.
- Lantai 2 (tim ide): riset, konten, desain, laporan, manajer.
- Data toko ada di folder data/. Jangan mengarang angka di luar data itu.
- Tiap agent menulis laporannya ke src/laporan.json di kuncinya sendiri:
  {"ringkasan": "...", "menunggu": ["..."], "mendesak": ["..."], "angka": [{"label": "...", "nilai": "..."}]}
- Jangan hapus laporan agent lain, cukup perbarui kuncimu.
- Jangan menulis nominal uang atau data rahasia; pakai jumlah barang/pesanan saja.
- Jawab pakai bahasa Indonesia santai, singkat.
