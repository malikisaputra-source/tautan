# Laporan Gudang & Cold Storage · 12 November 2026
Disusun oleh: Pak Joko (Lantai 1). Sumber: `data/gudang.csv`, `data/suhu-cold-storage.csv` (data fiktif).

## Stok tiap komoditas (12 November 2026)
- Gabah: masuk 1200 kg, keluar 800 kg, stok 5400 kg
- Cabai merah: masuk 150 kg, keluar 210 kg, stok 90 kg
- Bawang merah: masuk 300 kg, keluar 120 kg, stok 640 kg
- Jagung: masuk 500 kg, keluar 0 kg, stok 2100 kg

## Keluar lebih banyak dari masuk
- Cabai merah: keluar 210 kg, masuk 150 kg (selisih 60 kg). Stok tersisa 90 kg, paling sedikit di gudang.

## Suhu cold storage di luar batas aman (0-5 °C)
- 12:00: 6.2 °C (di atas batas)
- 16:00: 5.4 °C (di atas batas)
- Jam lain (00:00, 04:00, 08:00, 20:00) masih dalam batas aman. Pada 20:00 suhu kembali 4.3 °C.

## Menunggu keputusan pengurus
- Pemeriksaan kondisi barang di cold storage setelah suhu di atas batas pada 12:00-16:00.
- Tindak lanjut stok cabai merah yang keluar lebih banyak dari masuk.
