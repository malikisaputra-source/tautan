#!/usr/bin/env node
// Kira-kira waktu tiap kata dari naskah + durasi rekaman (untuk VO rekaman sendiri, tanpa ElevenLabs).
// Template oleh Maliki Saputra (@malikisaputra) — https://malikisaputra.biz.id · Lisensi Nonkomersial Maliki Studio 1.0
// Pakai: node alat/waktu_kira.mjs naskah.txt <durasi_detik>   → src/waktu.json
// Lalu dengarkan di `npm run studio` dan geser angka yang meleset.
import fs from "node:fs";
const [, , file = "naskah.txt", dur] = process.argv;
if (!dur) { console.error("Pakai: node alat/waktu_kira.mjs naskah.txt 55.2"); process.exit(1); }
const kalimat = fs.readFileSync(file, "utf8").split("\n").map((s) => s.trim()).filter(Boolean);
const huruf = kalimat.join(" ").replace(/\s/g, "").length;
const jeda = 0.35, per = (Number(dur) - jeda * kalimat.length) / huruf;
let t = 0; const sub = [];
for (const s of kalimat) {
  const kata = s.split(/\s+/);
  console.log(`${t.toFixed(2).padStart(6)} dtk  ${s.slice(0, 60)}`);
  for (let i = 0; i < kata.length; i += 4) {
    const g = kata.slice(i, i + 4), awal = t; const kk = g.map((k) => { const x = { k, t }; t += k.length * per; return x; });
    sub.push({ t0: awal, t1: t, teks: g.join(" "), kata: kk });
  }
  t += jeda;
}
fs.writeFileSync("src/waktu.json", JSON.stringify({ durasi: Number(dur), sub }));
console.log("✓ src/waktu.json");
