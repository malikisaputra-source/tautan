# Rekap Kunjungan Klinik Desa · 12 November 2026

Disusun oleh Nadia (Lantai 2, Klinik Desa). Sumber: `data/klinik.csv` (data fiktif).

## Total kunjungan
- 21 kunjungan pada 12 November 2026

## Kunjungan per keluhan umum
- Batuk pilek: 9 kunjungan (terbanyak)
- Demam: 6 kunjungan
- Darah tinggi (kontrol): 4 kunjungan
- Luka ringan: 2 kunjungan

## Keluhan terbanyak
- Batuk pilek, 9 dari 21 kunjungan

## Jadwal dokter
- Senin, Rabu, Jumat pukul 08.00-12.00

## Catatan
- Rekap ini hanya menghitung kunjungan menurut keluhan yang dicatat. Rekap ini tidak berisi diagnosis atau saran pengobatan. Pemeriksaan dan penanganan menjadi wewenang dokter.
- Data hanya berisi satu tanggal (12 November 2026), jadi tren belum bisa dibandingkan.
