---
name: jadwalkan-posting
description: Jadwalkan video di out/ ke Instagram (Meta Business Suite) dan TikTok (TikTok Studio) lewat Claude in Chrome — unggah, caption, sampul, label AI, jadwal, lalu verifikasi. Pakai saat pengguna minta "jadwalkan", "posting", "upload ke IG/TikTok".
---

# Jadwalkan posting IG + TikTok (Claude in Chrome)

Template oleh Maliki Saputra (@malikisaputra) — https://malikisaputra.biz.id · Lisensi Nonkomersial Maliki Studio 1.0.

## Syarat
- Ekstensi **Claude in Chrome** terpasang dan terhubung; pengguna sudah login di Chrome ke business.facebook.com dan tiktok.com/tiktokstudio.
- Login, password, kode 2FA = urusan pengguna. Jangan pernah mengetiknya.
- Bahan: `out/video.mp4`, `out/sampul.jpg`, `out/caption.txt`.

## Aturan keras
1. **Konfirmasi dulu** ke pengguna: akun tujuan, tanggal & jam (WIB), caption, sampul. Jadwalkan hanya setelah pengguna menjawab "ya".
2. Di Business Suite selalu pilih **Jadwal**, jangan **Bagikan** (Bagikan = langsung tayang).
3. Klik tombol "Berikutnya" **satu kali**, lalu screenshot. Halaman bisa melompat langsung ke tahap terakhir; klik kedua bisa mengenai "Bagikan".
4. Sebelum klik tombol akhir, zoom tombol kanan bawah: harus bertuliskan **"Jadwalkan"** (IG) / **"Schedule"** (TikTok).
5. Kerja di tab baru; jangan menyentuh tab milik pengguna; tutup tab sendiri setelah selesai.
6. Postingan terjadwal TikTok **tidak bisa diedit**, hanya dihapus — pastikan sampul & caption benar sebelum Schedule.

## Siapkan file (alat unggah Chrome maks ±10 MB per file)
```bash
mkdir -p out/unggah
ffmpeg -y -i out/video.mp4 -c:v libx264 -b:v 6M -maxrate 7M -bufsize 12M -pix_fmt yuv420p -c:a aac -b:a 192k -movflags +faststart out/unggah/video.mp4
cd out/unggah && split -b 9400000 -a 2 video.mp4 bagian- && cp ../sampul.jpg .
```
(Tanpa ffmpeg: `npx remotion ffmpeg …` atau langsung split file aslinya.)

Cara menyatukan potongan di halaman (dipakai di IG dan TikTok):
1. Lewat javascript_tool: buat `<input type=file id=__tmp>` fixed di pojok kiri atas, simpan tiap file yang masuk ke `window.__p` (event `change`).
2. `find` input itu → `file_upload` tiap `bagian-aa`, `bagian-ab`, … **satu per panggilan**, urut.
3. `new File(window.__p, 'video.mp4', {type:'video/mp4'})` → DataTransfer → set ke input file milik situs → dispatch `input` + `change`. Hapus `__tmp`.

## Instagram (Meta Business Suite)
1. Buka business.facebook.com/latest/posts → Konten → **Buat reel**.
2. Sebelum klik "Tambahkan Video": override `HTMLInputElement.prototype.click` dan `showPicker` supaya input file disimpan ke `window.__ambil` alih-alih membuka pemilih file Mac. Klik "Tambahkan Video", lalu satukan potongan ke `window.__ambil`.
3. **Posting ke**: buka dropdown, hapus centang Page Facebook bila hanya Instagram.
4. **Caption**: fokus kotak keterangan (contenteditable), tempel isi `caption.txt` (ClipboardEvent paste atau ketik). Cek panjang teks.
5. **Sampul**: Gambar mini → tab "Unggah gambar" → link "Unggah gambar" (tertangkap ke `__ambil`) → unggah `sampul.jpg` dengan cara yang sama.
6. Klik **Berikutnya** sekali → screenshot → bagian "Opsi penjadwalan" → tab **Jadwal** → tanggal dari kalender, jam: klik angka jam lalu ketik (mis. `20`), klik menit lalu ketik (`30`) → zoom → **Jadwalkan**.
7. Verifikasi: Konten → tab **Dijadwalkan** → cari kata dari caption → tanggal & jam benar, judul = caption (bukan "Reel Anda").
8. Business Suite tidak punya label AI untuk Reels: ingatkan pengguna menyalakan label AI / menambah kolaborator dari aplikasi IG setelah tayang.

## TikTok (TikTok Studio)
1. Buka tiktok.com/tiktokstudio/upload. Satukan potongan ke `input[type=file][accept="video/*"]`. Tunggu "Uploaded".
2. **Deskripsi**: klik editor, pilih semua & hapus, tempel `caption.txt` (ClipboardEvent paste). Tutup dropdown tagar dengan klik area kosong.
3. **Sampul**: klik "Edit cover" → tab "Upload cover" → unggah `sampul.jpg` → Confirm. (Kalau tidak bisa, pilih frame berjudul.)
4. **When to post** → Schedule → tanggal dulu (kalender), lalu jam: scroll kolom jam & menit, klik angkanya. Cek kolom menampilkan jam yang benar.
5. **Show more** → nyalakan **AI-generated content** (wajib bila gambar/suara AI) → "Turn on" bila diminta.
6. Zoom tombol → **Schedule**. Verifikasi di tiktokstudio/content (kotak cari → kata dari caption → tanggal & jam).

## Lapor ke pengguna
Akun, platform, tanggal & jam, apa yang sudah dicek, dan pengingat: pasang komentar sematan (bila ada) setelah tayang.
