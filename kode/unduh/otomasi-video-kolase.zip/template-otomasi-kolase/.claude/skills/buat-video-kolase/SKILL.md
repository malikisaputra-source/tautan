---
name: buat-video-kolase
description: Buat reel kolase kertas 9:16 (judul serif raksasa, objek potong bertepi putih, kertas sobek, anotasi tangan, grafik 15 fps) dari satu topik — riset, naskah, VO, gambar lewat Gemini API, potong latar, komposisi Remotion, render, sampul, caption. Pakai saat pengguna minta "video kolase", "reel kolase", "gaya Vox", atau menyebut topik untuk dibuat jadi video.
---

# Buat video kolase (template Maliki Studio)

Template oleh Maliki Saputra (@malikisaputra) — https://malikisaputra.biz.id · Lisensi Nonkomersial Maliki Studio 1.0.
Contoh jadi: `src/KolaseGedungSate.tsx` (topik Gedung Sate). **Salin file itu untuk topik baru**, jangan mulai dari nol.

## Aturan tetap
- Tanya pengguna dulu sebelum: menulis naskah final, memakai kredit API berbayar dalam jumlah besar, dan posting.
- Klaim di layar hanya yang ada di naskah. Fakta wajib bersumber (buku/jurnal/situs resmi); cerita populer ditandai "konon".
- Gambar AI diberi label "ilustrasi AI" di layar; caption menyebut AI (gambar & suara).
- Jangan pakai nama/logo "Vox" atau merek orang. Jangan menyalin rupa karya orang lain; ambil polanya.
- Teks penting di x 100–900 dan y ≤ 1250 (bawah tertutup tombol/caption Reels/TikTok).

## Alur
1. **Riset → naskah.** 10–12 kalimat (±45–55 dtk) di `naskah.txt`, satu kalimat per baris: hook pertanyaan kontras → jawaban singkat → kronologi/penjelasan → fakta kejutan → penutup/CTA. Tulis sumber per kalimat di `sumber.md`. **Minta persetujuan pengguna.**
2. **VO.**
   - ElevenLabs (bila `.env` berisi kunci): `node alat/vo_elevenlabs.mjs naskah.txt` → `public/vo.mp3` + `src/waktu.json`, lalu cetak detik awal tiap kalimat.
   - Rekaman sendiri: simpan `public/vo.mp3`, ukur durasinya, `node alat/waktu_kira.mjs naskah.txt <durasi>`.
   - Ubah `PAKAI_VO = true`.
3. **Daftar gambar.** Dari naskah, tulis `bahan/gambar.json` (`[{ "nama", "prompt" }]`) memakai pola `PROMPT.md`: 1 objek utama terisolasi latar putih, 1 latar tekstur, 1–2 close-up detail, 1 lembar stiker 3x3, 1 foto arsip (2.5D), tokoh/siluet bila perlu. Selalu tulis "TERISOLASI di latar putih polos" untuk objek yang akan dipotong, dan "tanpa teks".
4. **Buat gambar** dengan Gemini milik pengguna: `node alat/gemini_gambar.mjs --daftar bahan/gambar.json`. Buka tiap hasil (Read) dan **periksa**: jumlah detail, tanggal, lambang, tulisan acak, tangan aneh. Ulangi prompt yang gagal.
5. **Potong latar** (macOS Vision, gratis):
   - satu objek: `swiftc -O alat/potong.swift -o alat/potong` lalu `alat/potong bahan/x.png public/kolase/x-pot.png`
   - lembar stiker: `swiftc -O alat/pisah.swift -o alat/pisah` lalu `alat/pisah bahan/stiker.png public/kolase/stk`
   - latar tanpa subjek (2.5D): `python3 alat/bersihkan_latar.py …` (lihat komentar di file).
   Salin gambar latar (tanpa potong) ke `public/kolase/`.
6. **Komposisi.** Salin `src/KolaseGedungSate.tsx` → `src/Kolase<Topik>.tsx`, daftarkan di `src/Root.tsx`. Satu adegan per 1–2 kalimat; `t` adegan = detik awal kalimat (dari langkah 2). Tiap adegan: satu `JudulBesar` (1 kata, ≤6 huruf muat x 100–900), objek dengan `Objek`, satu anotasi `Coret`/label, lingkaran warna di belakang objek. Satu adegan angka menghitung naik (selesai saat VO menyebut angkanya).
7. **Cek.** `npm run cek`, lalu still tiap adegan: `npx remotion still <Id> out/a1.png --frame=<detik×30>` — **lihat gambarnya**: anotasi/serpih tidak menutup huruf atau wajah, teks tidak keluar layar, angka cocok dengan VO.
8. **Render.** `npx remotion render <Id> out/video.mp4 --concurrency 8`. Ambil bingkai tiap 1,5 dtk dan periksa sekali lagi.
9. **Sampul & caption.** `out/sampul.jpg` (bingkai pembuka + judul pertanyaan besar), `out/caption.txt` (baris pertama hook, ringkasan, catatan "konon", sumber, label AI, maks 5 tagar). Serahkan ke pengguna; **jangan posting sendiri**.

## Kalau Gemini API gagal
- 429/kuota: tunggu atau pakai model lain (`GEMINI_MODEL_GAMBAR` di `.env`).
- Ditolak karena tokoh nyata: pakai foto domain publik (Wikimedia Commons, cek lisensi) lalu potong dengan `potong.swift`.
- Alternatif tanpa API: pengguna membuat gambar di gemini.google.com dengan prompt dari `bahan/gambar.json`, simpan ke `bahan/` dengan nama yang sama, lalu lanjut langkah 5.
