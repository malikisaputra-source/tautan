# Pengumuman & Caption · Koperasi Merah Putih Desa Sukamaju (fiktif)

Sumber: `data/promo.txt`. Draf saja, belum dikirim. Pengurus perlu menyetujui sebelum dikirim.

## 1. Pengumuman grup WA anggota

Assalamualaikum, Bapak/Ibu anggota Koperasi Merah Putih Desa Sukamaju.

**Promo minggu ini (14–20 Nov 2026):**
- Mi instan: beli 10 gratis 1
- Minyak goreng 1 L: stok banyak

**Kegiatan:**
- Senam sehat & cek tensi gratis
- Sabtu, 15 Nov, pukul 07.00
- Di halaman koperasi

Terima kasih.

## 2. Caption media sosial

**Caption 1 · Promo mi instan**
Promo 14–20 Nov 2026 di Koperasi Merah Putih Desa Sukamaju: mi instan beli 10 gratis 1.

**Caption 2 · Minyak goreng**
Minyak goreng 1 L stok banyak di Koperasi Merah Putih Desa Sukamaju. Berlaku minggu ini, 14–20 Nov 2026.

**Caption 3 · Senam sehat**
Senam sehat & cek tensi gratis! Sabtu, 15 Nov, pukul 07.00, di halaman koperasi.

## Catatan untuk pengurus (menunggu)
- Persetujuan pengurus sebelum pengumuman dan caption dikirim/diunggah.
- Syarat promo mi instan (merek, batas per anggota, khusus anggota atau umum) tidak ada di data, jadi tidak ditulis.
- Harga minyak goreng tidak ada di data, jadi tidak ditulis.
