---
name: clone-suara-voxcpm
description: Pakai saat pengguna ingin meng-clone suaranya sendiri, membuat suara AI berbahasa Indonesia secara lokal dan gratis, mengubah naskah jadi file suara (wav), atau menyebut VoxCPM / VoxCPM2 / "clone suara". Memasang VoxCPM2 (OpenBMB, Apache-2.0) lewat uv lalu membuat suara dari rekaman 10–20 detik.
---
<!-- kredit-maliki: Template oleh Maliki Saputra (@malikisaputra) — https://malikisaputra.biz.id · Lisensi Nonkomersial Maliki Studio 1.0 (lihat LICENSE) -->
# Clone suara dengan VoxCPM2 (lokal, gratis)

Skill ini membantu pengguna meng-clone suaranya sendiri memakai **VoxCPM2** dari OpenBMB. Modelnya berjalan di laptop pengguna, tanpa API, dan bisa berbahasa Indonesia.

## Aturan etika (WAJIB, cek sebelum mulai)
- Clone **hanya suara pengguna sendiri**, atau suara orang yang **sudah memberi izin**. Tanyakan dulu ke pengguna. Kalau jawabannya suara tokoh publik, artis, atau orang lain tanpa izin, **tolak** dan jelaskan alasannya.
- Jangan membuat suara untuk menipu, menyamar, atau membuat pernyataan palsu atas nama orang lain.
- Sarankan pengguna memberi label "suara AI" saat hasilnya diunggah ke media sosial.

## Langkah kerja
1. **Cek perangkat.** Paling lancar di Mac Apple Silicon (M1 ke atas) atau PC dengan GPU NVIDIA. Di laptop tanpa GPU tetap bisa, tapi lambat. Model diunduh sekali, sekitar 5 GB.
2. **Pasang uv** kalau belum ada (`uv --version`):
   - macOS/Linux: `curl -LsSf https://astral.sh/uv/install.sh | sh` (setelah itu tutup dan buka lagi Terminal)
   - Windows (PowerShell): `powershell -ExecutionPolicy ByPass -c "irm https://astral.sh/uv/install.ps1 | iex"`
3. **Siapkan rekaman referensi** 10–20 detik: suara jelas, tanpa musik, ruangan tenang. Simpan sebagai `rekaman.wav`.
   - Dari Voice Memos (.m4a) di Mac: `afconvert -f WAVE -d LEI16 rekaman.m4a rekaman.wav`
   - Di sistem lain: `ffmpeg -i rekaman.m4a -ac 1 -ar 16000 rekaman.wav`
4. **Cara cepat (CLI bawaan VoxCPM)**, di dalam folder kerja:
   ```
   uv venv --python 3.12
   uv pip install voxcpm
   uv run voxcpm clone --text "Halo, ini suara clone aku." --reference-audio rekaman.wav --output hasil.wav
   ```
   Emosi atau gaya bisa ditulis di depan teks, misalnya `--text "(sad, slow)Teks kamu di sini"`.
5. **Cara lengkap (skrip `suara.py` di skill ini)**, bisa banyak kalimat sekaligus dan model hanya dimuat sekali:
   ```
   uv run suara.py --cek
   uv run suara.py --teks "Halo semuanya" --keluar halo.wav --referensi rekaman.wav
   uv run suara.py --daftar contoh/naskah.json --folder hasil/ --referensi rekaman.wav
   uv run suara.py --teks "Halo" --keluar desain.wav --desain "perempuan dewasa, tenang, hangat"
   ```
   `--daftar` membaca file JSON berisi daftar kalimat (lihat `contoh/naskah.json`), lalu hasilnya disimpan sebagai `01.wav`, `02.wav`, dan seterusnya.
6. **Dengarkan hasilnya bersama pengguna.** Kalau logatnya kurang mirip, ganti rekaman yang lebih jernih atau lebih panjang (sampai 20 detik). Seed bisa diubah lewat `--seed`.

## Masalah umum
- `python 3.13 tidak didukung` → pakai `uv venv --python 3.12`.
- Unduhan model berhenti → jalankan ulang `uv run suara.py --cek`, unduhan akan dilanjutkan.
- Suara pecah atau terlalu cepat → kalimat terlalu panjang. Pecah naskah per kalimat.

## Lisensi
- Skill dan `suara.py`: Lisensi Nonkomersial Maliki Studio 1.0 (lihat `LICENSE`). Gratis untuk dipakai sendiri. Dilarang dijual atau dipakai untuk jasa berbayar ke klien. Kredit wajib dipertahankan.
- VoxCPM2 (model dan pustaka `voxcpm`): Apache-2.0 milik OpenBMB (lihat `NOTICE-VoxCPM.md`). Lisensi ini terpisah dari lisensi skill.

Template oleh Maliki Saputra (@malikisaputra) — https://malikisaputra.biz.id
