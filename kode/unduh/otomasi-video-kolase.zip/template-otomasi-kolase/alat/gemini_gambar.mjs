#!/usr/bin/env node
// Buat gambar lewat Gemini API (milik pengguna sendiri) dan simpan ke file.
// Template oleh Maliki Saputra (@malikisaputra) — https://malikisaputra.biz.id · Lisensi Nonkomersial Maliki Studio 1.0
//
// Pakai:
//   node alat/gemini_gambar.mjs "<prompt>" bahan/gedung.png
//   node alat/gemini_gambar.mjs --daftar bahan/gambar.json      (banyak gambar sekaligus)
//
// gambar.json = [{ "nama": "gedung", "prompt": "..." }, ...]  → disimpan ke bahan/<nama>.png
// Kunci API dibaca dari file .env (GEMINI_API_KEY=...) atau variabel lingkungan.
// Model bisa diganti lewat GEMINI_MODEL_GAMBAR (default gemini-2.5-flash-image).
import fs from "node:fs";
import path from "node:path";

const akar = path.resolve(path.dirname(new URL(import.meta.url).pathname), "..");
const env = path.join(akar, ".env");
if (fs.existsSync(env)) {
  for (const baris of fs.readFileSync(env, "utf8").split("\n")) {
    const m = baris.match(/^\s*([A-Z0-9_]+)\s*=\s*(.*)\s*$/);
    if (m && !process.env[m[1]]) process.env[m[1]] = m[2].replace(/^["']|["']$/g, "");
  }
}
const KUNCI = process.env.GEMINI_API_KEY;
const MODEL = process.env.GEMINI_MODEL_GAMBAR || "gemini-2.5-flash-image";
if (!KUNCI) {
  console.error("GEMINI_API_KEY belum diisi. Salin .env.example jadi .env lalu isi kuncimu dari https://aistudio.google.com/apikey");
  process.exit(1);
}

async function buat(prompt, keluar) {
  const url = `https://generativelanguage.googleapis.com/v1beta/models/${MODEL}:generateContent`;
  for (let coba = 1; coba <= 3; coba++) {
    const r = await fetch(url, {
      method: "POST",
      headers: { "Content-Type": "application/json", "x-goog-api-key": KUNCI },
      body: JSON.stringify({ contents: [{ parts: [{ text: prompt }] }], generationConfig: { responseModalities: ["IMAGE", "TEXT"] } }),
    });
    const j = await r.json().catch(() => ({}));
    if (!r.ok) {
      const pesan = j?.error?.message || r.statusText;
      if ((r.status === 429 || r.status >= 500) && coba < 3) { console.warn(`  ${r.status}, coba lagi…`); await new Promise((s) => setTimeout(s, 4000 * coba)); continue; }
      throw new Error(`Gemini ${r.status}: ${pesan}`);
    }
    const bagian = j?.candidates?.[0]?.content?.parts || [];
    const gbr = bagian.find((p) => p.inlineData?.data || p.inline_data?.data);
    if (!gbr) {
      const teks = bagian.map((p) => p.text).filter(Boolean).join(" ");
      throw new Error(`Gemini tidak mengirim gambar. ${teks || JSON.stringify(j?.promptFeedback || {})}`);
    }
    const data = (gbr.inlineData || gbr.inline_data).data;
    fs.mkdirSync(path.dirname(keluar), { recursive: true });
    fs.writeFileSync(keluar, Buffer.from(data, "base64"));
    console.log(`✓ ${keluar}`);
    return;
  }
}

const arg = process.argv.slice(2);
if (arg[0] === "--daftar") {
  const daftar = JSON.parse(fs.readFileSync(arg[1], "utf8"));
  const folder = path.dirname(arg[1]);
  let gagal = 0;
  for (const d of daftar) {
    try { await buat(d.prompt, path.join(folder, `${d.nama}.png`)); }
    catch (e) { gagal++; console.error(`✗ ${d.nama}: ${e.message}`); }
  }
  process.exit(gagal ? 1 : 0);
} else if (arg.length === 2) {
  await buat(arg[0], arg[1]).catch((e) => { console.error(`✗ ${e.message}`); process.exit(1); });
} else {
  console.error('Pakai: node alat/gemini_gambar.mjs "<prompt>" <keluar.png>  atau  --daftar bahan/gambar.json');
  process.exit(1);
}
