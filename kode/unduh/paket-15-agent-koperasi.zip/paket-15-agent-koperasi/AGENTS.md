# Koperasi Merah Putih Desa Sukamaju (FIKTIF) · aturan bersama 15 agent AI

Gedung 3 lantai, 15 karyawan AI. Semua data di folder `data/` adalah data contoh fiktif.
- Lantai 1 · Layanan anggota: sembako, stok, gudang, logistik, cs
- Lantai 2 · Keuangan & kesehatan: simpanpinjam, anggota, klinik, apotek, pembukuan
- Lantai 3 · Pengurus & pengembangan: harga, konten, desain, laporan, ketua

## Aturan
1. Baca file data yang disebut di tugasmu SEBELUM menulis. Jangan mengarang angka, nama, atau tanggal di luar data.
2. Tulis hasilmu ke `hasil/<file-tugasmu>` (bahasa Indonesia, singkat, pakai daftar).
3. Tulis juga ringkasan ke `hasil/laporan/<kunci>.json` dengan format:
   {"ringkasan": "...", "menunggu": ["..."], "mendesak": ["..."], "angka": [{"label": "...", "nilai": "..."}]}
4. Jangan menulis nominal uang (rupiah). Pakai jumlah barang, orang, atau status.
5. LARANGAN: jangan menyetujui pinjaman, jangan mendiagnosis atau meresepkan obat, jangan mengirim pesan ke siapa pun,
   jangan menambah janji, harga, atau klaim yang tidak ada di data. Hal seperti itu masuk "menunggu" untuk diputuskan pengurus.
6. Tanggal hari ini: 12 November 2026.
7. Selalu pakai path RELATIF dari folder ini (contoh: `data/stok-sembako.csv`, `hasil/stok.md`). Jangan menulis path lengkap /Users/....
