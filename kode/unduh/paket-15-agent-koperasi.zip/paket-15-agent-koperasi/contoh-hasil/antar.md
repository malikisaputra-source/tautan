# Daftar Antaran · Logistik (Rina, Lantai 1)

Sumber: `data/antar.csv` · Tanggal: 12 November 2026

- Jumlah antaran: 7
- Jumlah RT tujuan: 4 (RT 01, 02, 03, 05)

## RT 01 (2 antaran)
- A01 · Bu Sumi · Beras 5 kg × 2
- A03 · Bu Inah · Telur × 3

## RT 02 (1 antaran)
- A06 · Pak Asep · Mi instan × 20

## RT 03 (2 antaran)
- A02 · Pak Darto · Minyak goreng 1 L × 4
- A05 · Bu Lilis · Beras 5 kg × 1

## RT 05 (2 antaran)
- A04 · Pak Ujang · Gula pasir 1 kg × 2
- A07 · Bu Neni · Telur × 2

## Catatan
- Tidak ada antaran ke RT 04 di data.
- Jadwal, jam, dan petugas antar tidak tercantum di data, jadi perlu ditetapkan pengurus.
