/**
 * ✏️ UBAH DI SINI: nama kantor, ruangan, agen, jadwal, dan data contoh.
 * Semua yang tampil di kantor diambil dari file ini. Nama dan angka di bawah fiktif.
 */

import laporanAgen from './laporan.json';

export const KANTOR = {
  nama: 'KOPDES MERAH PUTIH',
  /** Baris kecil di bawah nama (mis. nama perusahaan). */
  subjudul: 'Desa Sukamaju (fiktif) · Kantor AI · 3 lantai',
};

/** Nama tiap lantai (lantai berikutnya ditumpuk di atas). */
export const LANTAI = [
  { no: 1, label: 'Layanan anggota' },
  { no: 2, label: 'Keuangan & kesehatan' },
  { no: 3, label: 'Pengurus' },
] as const;

/** Ruangan per lantai, dari kiri ke kanan. Lebarnya ikut `x0`–`x1` (meter, −7…7), lantainya `warna`, karpetnya `karpet`. */
export const RUANGAN = [
  { key: 'gerai', label: 'Gerai sembako', lantai: 1, x0: -7, x1: 0.2, warna: '#d8d4cc', karpet: '#c8102e' },
  { key: 'gudang', label: 'Gudang & logistik', lantai: 1, x0: 0.2, x1: 7, warna: '#b9bec4', karpet: '#5b7a99' },
  { key: 'simpan', label: 'Simpan pinjam', lantai: 2, x0: -7, x1: 0.2, warna: '#e6e1d8', karpet: '#c8102e' },
  { key: 'klinik', label: 'Klinik & apotek', lantai: 2, x0: 0.2, x1: 7, warna: '#eef1f2', karpet: '#7fb8c9' },
  { key: 'kantor', label: 'Kantor koperasi', lantai: 3, x0: -7, x1: 0.2, warna: '#d9cbb5', karpet: '#c8102e' },
  { key: 'rapat', label: 'Ruang rapat', lantai: 3, x0: 0.2, x1: 7, warna: '#cdb99c', karpet: '#8a1f2b' },
] as const;
export type RoomKey = (typeof RUANGAN)[number]['key'];

export interface Agen {
  key: string;
  nama: string;
  /** Tugasnya, satu baris. */
  tugas: string;
  ruang: RoomKey;
  /** 1, 2, atau 3. */
  lantai: 1 | 2 | 3;
  /** Warna baju. */
  warna: string;
  /** Posisi meja di lantainya (x kiri–kanan −7…7, z belakang–depan −3…3). */
  x: number;
  z: number;
}

/** Lima belas agen, lima per lantai (posisi meja jangan bertumpuk). */
export const AGEN: Agen[] = [
  { key: 'sembako', nama: 'Dina', tugas: 'Rekap penjualan', ruang: 'gerai', lantai: 1, warna: '#e4572e', x: -5.3, z: -1.3 },
  { key: 'cs', nama: 'Fajar', tugas: 'Draf balasan WA', ruang: 'gerai', lantai: 1, warna: '#43aa8b', x: -3.0, z: -1.3 },
  { key: 'stok', nama: 'Bayu', tugas: 'Cek stok sembako', ruang: 'gerai', lantai: 1, warna: '#f2b134', x: -4.2, z: 1.3 },
  { key: 'gudang', nama: 'Pak Joko', tugas: 'Gudang & cold storage', ruang: 'gudang', lantai: 1, warna: '#3a86ff', x: 3.4, z: -1.3 },
  { key: 'logistik', nama: 'Rina', tugas: 'Jadwal antar per RT', ruang: 'gudang', lantai: 1, warna: '#2a9d8f', x: 5.3, z: 1.0 },
  { key: 'simpanpinjam', nama: 'Sari', tugas: 'Rekap simpan pinjam', ruang: 'simpan', lantai: 2, warna: '#ff5d8f', x: -5.3, z: -1.3 },
  { key: 'anggota', nama: 'Wati', tugas: 'Anggota & iuran', ruang: 'simpan', lantai: 2, warna: '#c77dff', x: -3.0, z: -1.3 },
  { key: 'pembukuan', nama: 'Hendra', tugas: 'Cocokkan transaksi', ruang: 'simpan', lantai: 2, warna: '#577590', x: -4.2, z: 1.3 },
  { key: 'klinik', nama: 'Nadia', tugas: 'Rekap klinik', ruang: 'klinik', lantai: 2, warna: '#4cc9f0', x: 3.4, z: -1.3 },
  { key: 'apotek', nama: 'Dimas', tugas: 'Stok & kedaluwarsa obat', ruang: 'klinik', lantai: 2, warna: '#80b918', x: 5.3, z: 1.0 },
  { key: 'harga', nama: 'Raka', tugas: 'Riset harga tani', ruang: 'kantor', lantai: 3, warna: '#3a86ff', x: -5.3, z: -1.3 },
  { key: 'konten', nama: 'Sekar', tugas: 'Pengumuman & caption', ruang: 'kantor', lantai: 3, warna: '#ff8fab', x: -3.0, z: -1.3 },
  { key: 'desain', nama: 'Lita', tugas: 'Poster promo', ruang: 'kantor', lantai: 3, warna: '#f15bb5', x: -4.2, z: 1.3 },
  { key: 'laporan', nama: 'Doni', tugas: 'Laporan mingguan', ruang: 'rapat', lantai: 3, warna: '#8d99ae', x: 3.4, z: -1.3 },
  { key: 'ketua', nama: 'Bu Rahma', tugas: 'Prioritas & keputusan', ruang: 'rapat', lantai: 3, warna: '#8b1e2b', x: 5.3, z: 1.0 },
];

export type Aktivitas = 'kerja' | 'laporan' | 'belajar';

const HK = [1, 2, 3, 4, 5];
/** Jadwal kerja (WIB). `agen: '*'` = semua agen. `hari` 1 = Senin … 7 = Minggu. `menit` = lama tampil. */
export const JADWAL: { agen: string[] | '*'; mulai: string; menit: number; hari: number[]; aktivitas: Aktivitas; label: string }[] = [
  { agen: ['sembako'], mulai: '07:30', menit: 75, hari: HK, aktivitas: 'kerja', label: 'rekap penjualan…' },
  { agen: ['stok'], mulai: '07:33', menit: 75, hari: HK, aktivitas: 'kerja', label: 'cek stok sembako…' },
  { agen: ['gudang'], mulai: '07:36', menit: 75, hari: HK, aktivitas: 'kerja', label: 'cek suhu cold storage…' },
  { agen: ['logistik'], mulai: '07:39', menit: 75, hari: HK, aktivitas: 'kerja', label: 'susun antaran per RT…' },
  { agen: ['cs'], mulai: '07:42', menit: 75, hari: HK, aktivitas: 'kerja', label: 'draf balasan WA…' },
  { agen: ['simpanpinjam'], mulai: '07:45', menit: 75, hari: HK, aktivitas: 'kerja', label: 'rekap pengajuan…' },
  { agen: ['anggota'], mulai: '07:48', menit: 75, hari: HK, aktivitas: 'kerja', label: 'cek iuran anggota…' },
  { agen: ['klinik'], mulai: '07:51', menit: 75, hari: HK, aktivitas: 'kerja', label: 'rekap kunjungan…' },
  { agen: ['apotek'], mulai: '07:54', menit: 75, hari: HK, aktivitas: 'kerja', label: 'cek kedaluwarsa obat…' },
  { agen: ['pembukuan'], mulai: '07:57', menit: 75, hari: HK, aktivitas: 'kerja', label: 'cocokkan transaksi…' },
  { agen: ['harga'], mulai: '08:00', menit: 60, hari: HK, aktivitas: 'kerja', label: 'bandingkan harga tani…' },
  { agen: ['konten'], mulai: '08:03', menit: 60, hari: HK, aktivitas: 'kerja', label: 'tulis pengumuman…' },
  { agen: ['desain'], mulai: '08:06', menit: 60, hari: HK, aktivitas: 'kerja', label: 'bikin poster promo…' },
  { agen: ['laporan'], mulai: '08:09', menit: 60, hari: HK, aktivitas: 'kerja', label: 'gabung laporan…' },
  { agen: ['ketua'], mulai: '08:12', menit: 60, hari: HK, aktivitas: 'kerja', label: 'tetapkan prioritas…' },
  { agen: '*', mulai: '15:42', menit: 25, hari: HK, aktivitas: 'laporan', label: 'menulis laporan harian…' },
  { agen: '*', mulai: '20:00', menit: 120, hari: [1, 2, 3, 4, 5, 6, 7], aktivitas: 'belajar', label: 'belajar malam…' },
];

/** Jam kantor: di luar jadwal, agen "siap menerima perintah" (atau ngopi, lihat papan, ngobrol). */
export const JAM_KANTOR = { buka: '07:30', tutup: '18:00' };

export interface Laporan {
  /** Ringkasan hari ini (gelembung di atas kepala). */
  ringkasan?: string;
  /** Butir yang menunggu keputusanmu (tanda "!" dan Mission Board). */
  menunggu?: string[];
  /** Butir mendesak (mejanya berkedip). */
  mendesak?: string[];
  /** Angka hari ini (Mission Board). Jangan isi nominal uang kalau videonya mau dibagikan. */
  angka?: { label: string; nilai: string }[];
}

/**
 * Laporan hari ini per agen. Ini data contoh; untuk data asli, isi dari API/JSON agenmu (lihat README, "Sambungkan agen
 * asli").
 */
export const LAPORAN: Record<string, Laporan> = laporanAgen;

/** Timelapse: satu hari dalam tiga babak (detik = lama tiap babak di video). */
export const BABAK = [
  { dari: '07:28', sampai: '08:44', detik: 12, judul: 'Pagi · 15 agent mulai kerja' },
  { dari: '15:36', sampai: '16:10', detik: 9, judul: 'Sore · laporan harian' },
  { dari: '19:52', sampai: '20:26', detik: 9, judul: 'Malam · belajar' },
];
