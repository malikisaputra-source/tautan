# Simpan Pinjam · per 12 November 2026
Sumber: `data/simpan-pinjam.csv` · Disusun: Sari (Lantai 2)

## Pengajuan baru: 2 (menunggu verifikasi pengurus, BELUM disetujui)
- P01 · Pak Darto: menunggu verifikasi
- P02 · Bu Neni: menunggu verifikasi
- Keputusan ada di pengurus. Sari tidak menyetujui atau menolak pinjaman.

## Angsuran jatuh tempo 12–19 Nov 2026: 2
- P03 · Pak Ujang: jatuh tempo 15 Nov 2026 (status: berjalan)
- P04 · Bu Sumi: jatuh tempo 17 Nov 2026 (status: berjalan)

## Angsuran terlambat: 1
- P05 · Pak Asep: jatuh tempo 5 Nov 2026, status terlambat (lewat 7 hari)

## Catatan
- P06 · Bu Lilis: jatuh tempo 28 Nov 2026, di luar rentang minggu ini.
- Belum ada pesan atau pengingat yang dikirim ke anggota. Tindak lanjut menunggu arahan pengurus.
