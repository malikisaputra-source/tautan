# Draf Balasan WhatsApp · 12 November 2026

Disusun oleh Fajar (CS WhatsApp, Lantai 1).
**STATUS: DRAF, BELUM DIKIRIM.** Semua balasan harus diperiksa pengurus dulu sebelum dikirim.

Sumber data: `data/pesan-wa.txt`, `data/stok-sembako.csv`, `data/antar.csv`, `data/klinik.csv`, `data/apotek.csv`, `data/anggota.csv`, `data/simpan-pinjam.csv`.

---

## 1. [08.12] Bu Sumi · beras 5 kg, pesan 2
**Catatan internal:**
- Stok Beras 5 kg: 12 karung (di bawah batas minimum 20).
- Di `data/antar.csv` sudah ada A01 · Bu Sumi · Beras 5 kg · 2 (RT 01). Kemungkinan pesanan ini sudah tercatat; perlu dicek logistik supaya tidak dobel.
- Jadwal antar tidak ada di data, jadi jangan dijanjikan.

**Draf balasan:**
> Waalaikumsalam, Bu Sumi. Terima kasih sudah menghubungi Koperasi Merah Putih Desa Sukamaju. Saat ini beras 5 kg masih tersedia. Pesanan 2 karung atas nama Ibu sedang kami cek ke bagian pengantaran, nanti petugas kami kabari lagi untuk waktu antarnya ya, Bu.

---

## 2. [08.40] Pak Darto · jam buka & syarat simpan pinjam
**Catatan internal:**
- Jam buka layanan simpan pinjam dan syarat pengajuan TIDAK ada di data. Jangan dikarang.
- Di `data/simpan-pinjam.csv`, Pak Darto sudah punya pengajuan baru (P01) berstatus "menunggu verifikasi". CS tidak boleh memberi keputusan pinjaman.

**Draf balasan:**
> Selamat pagi, Pak Darto. Terima kasih atas pertanyaannya. Untuk jam layanan dan syarat pengajuan simpan pinjam, kami teruskan dulu ke petugas simpan pinjam supaya Bapak dapat info yang tepat. Nanti petugas kami yang menghubungi Bapak ya.

---

## 3. [09.05] Bu Inah · KELUHAN telur pecah 3 butir, minta ganti
**Catatan internal:**
- Keluhan → masuk daftar tunggu pengurus. Penggantian TIDAK boleh dijanjikan oleh CS.
- Data antar: A03 · Bu Inah · Telur · 3 (RT 01).
- Stok telur 10 kg (di bawah batas minimum 25).

**Draf balasan:**
> Selamat pagi, Bu Inah. Mohon maaf atas ketidaknyamanannya, telur yang diterima ada yang pecah. Keluhan Ibu sudah kami catat dan kami teruskan ke pengurus untuk ditindaklanjuti. Kalau berkenan, boleh kirimkan foto telurnya untuk melengkapi laporan. Nanti pengurus kami yang mengabari Ibu.

---

## 4. [10.15] Pak Ujang · obat maag di apotek
**Catatan internal:**
- CS tidak boleh mendiagnosis atau menyarankan obat.
- Data apotek: Antasida tablet stok 15 (di bawah batas minimum 50), kedaluwarsa 20 Desember 2026. Ketersediaan sebaiknya dikonfirmasi petugas apotek.

**Draf balasan:**
> Selamat siang, Pak Ujang. Terima kasih sudah bertanya. Untuk obat maag, silakan datang dan konsultasi langsung ke petugas apotek koperasi supaya mendapat obat yang sesuai. Kalau keluhannya berat atau tidak membaik, sebaiknya periksa ke dokter klinik ya, Pak. Jadwal dokter klinik: Senin, Rabu, Jumat pukul 08.00-12.00.

---

## 5. [11.30] Bu Lilis · jadwal dokter klinik
**Catatan internal:**
- Data `data/klinik.csv`: jadwal dokter Senin Rabu Jumat 08.00-12.00.

**Draf balasan:**
> Selamat siang, Bu Lilis. Jadwal dokter di klinik koperasi adalah hari Senin, Rabu, dan Jumat, pukul 08.00-12.00. Terima kasih, Bu.

---

## 6. [13.02] Pak Asep · mau daftar anggota
**Catatan internal:**
- Di `data/anggota.csv`, Pak Asep (M006) sudah tercatat sebagai anggota **aktif**. Perlu dicek apakah ini orang yang sama atau ia mendaftarkan orang lain.
- Syarat/berkas pendaftaran anggota TIDAK ada di data. Jangan dikarang.

**Draf balasan:**
> Selamat siang, Pak Asep. Terima kasih atas minatnya. Menurut catatan kami, nama Pak Asep sudah terdaftar sebagai anggota. Apakah pendaftaran ini untuk Bapak sendiri atau untuk anggota keluarga lain? Untuk berkas yang perlu dibawa, kami tanyakan dulu ke petugas keanggotaan dan nanti kami kabari ya, Pak.

---

## Daftar tunggu pengurus
- **Keluhan Bu Inah:** 3 butir telur pecah saat diantar (A03), minta diganti. Keputusan penggantian di tangan pengurus.
- **Bu Sumi:** pastikan pesanan 2 karung beras sama dengan A01 di daftar antar (jangan dobel) dan tentukan jadwal antar.
- **Pak Darto:** jam buka & syarat simpan pinjam belum ada di data; pengajuan P01 masih menunggu verifikasi.
- **Pak Asep:** sudah tercatat anggota aktif (M006) tapi bertanya cara daftar; syarat pendaftaran belum ada di data.
- **Pak Ujang:** pertanyaan obat diteruskan ke petugas apotek/klinik.
