# Apotek Desa · Cek Stok & Kedaluwarsa Obat
Petugas: Dimas (Lantai 2) · Data: `data/apotek.csv` · Tanggal cek: 12 November 2026

Catatan: laporan ini hanya soal stok dan tanggal kedaluwarsa. Tidak berisi saran pengobatan atau resep.

## 1. Stok di bawah batas minimum (3 obat)
- Parasetamol 500 mg: stok 40, batas minimum 100 (kurang 60)
- Antasida tablet: stok 15, batas minimum 50 (kurang 35)
- Amoksisilin 500 mg: stok 30, batas minimum 40 (kurang 10)

## 2. Kedaluwarsa dalam 60 hari, sampai 11 Januari 2027 (3 obat)
- Salep luka: kedaluwarsa 30 November 2026 (18 hari lagi), stok 12
- Antasida tablet: kedaluwarsa 20 Desember 2026 (38 hari lagi), stok 15
- Amoksisilin 500 mg: kedaluwarsa 30 Desember 2026 (48 hari lagi), stok 30

## 3. Aman (stok cukup, kedaluwarsa lebih dari 60 hari)
- Oralit: stok 80 (minimum 40), kedaluwarsa 15 Maret 2027
- Vitamin C: stok 200 (minimum 100), kedaluwarsa 1 Oktober 2027

## Perhatian
- Antasida tablet dan Amoksisilin 500 mg kena dua masalah sekaligus: stok kurang DAN segera kedaluwarsa.
- Salep luka paling dekat kedaluwarsa (18 hari).

## Menunggu keputusan pengurus
- Pengadaan ulang Parasetamol 500 mg, Antasida tablet, dan Amoksisilin 500 mg (jumlah dan waktu pesan).
- Penanganan stok yang segera kedaluwarsa (Salep luka, Antasida tablet, Amoksisilin 500 mg): penarikan/pemusnahan sesuai prosedur.
- Penggunaan obat oleh anggota tetap lewat tenaga kesehatan; apotek tidak meresepkan.
