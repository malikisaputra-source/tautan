# Otomasi Video Kolase · Claude Code + Gemini (Mac)

> Template oleh Maliki Saputra (@malikisaputra) — https://malikisaputra.biz.id. Gratis dengan **Lisensi Nonkomersial Maliki Studio 1.0**: boleh dipakai untuk belajar, pribadi, atau usaha/organisasimu sendiri; wajib cantumkan kredit; **dilarang dijual, dijual ulang, atau dipakai untuk jasa berbayar ke pihak lain**. Lihat `LICENSE`.

Ketik satu topik ke Claude Code → Claude riset, menulis naskah, membuat gambar lewat **Gemini milikmu**, memotong objek, menyusun video kolase 9:16 di Remotion, merender, lalu membuat sampul dan caption. Kamu tinggal menyetujui naskah dan mengecek hasil.

## Isi paket
| File | Fungsi |
|---|---|
| `.claude/skills/buat-video-kolase/SKILL.md` | Alur kerja lengkap yang diikuti Claude |
| `.claude/skills/jadwalkan-posting/SKILL.md` | Jadwalkan ke IG (Business Suite) + TikTok Studio lewat Claude in Chrome |
| `CLAUDE.md` | Aturan proyek untuk Claude |
| `PROMPT.md` | Pola prompt gambar (objek, latar, stiker, arsip, tokoh) |
| `alat/gemini_gambar.mjs` | Buat gambar lewat Gemini API → `bahan/` |
| `alat/vo_elevenlabs.mjs` | (opsional) VO + waktu kata lewat ElevenLabs |
| `alat/waktu_kira.mjs` | Waktu kata untuk VO rekaman sendiri |
| `alat/potong.swift`, `alat/pisah.swift` | Potong latar objek / lembar stiker (Vision macOS, gratis) |
| `src/KolaseGedungSate.tsx` | Contoh video jadi (Gedung Sate) yang disalin untuk topik baru |

## Pasang (sekali)
1. **Claude Code** (paket Claude Pro atau lebih): https://claude.com/claude-code
2. **Node.js 18+**: https://nodejs.org
3. **Xcode Command Line Tools** (untuk alat potong): `xcode-select --install`
4. Di folder ini: `npm install`
5. Buat kunci **Gemini API** di https://aistudio.google.com/apikey → salin `.env.example` jadi `.env` → isi `GEMINI_API_KEY=`.
   Catatan: langganan Gemini (Google One AI) **bukan** kunci API. Kunci API punya kuota gratis; pemakaian besar bisa berbayar sesuai harga Google.
6. Uji: `node alat/gemini_gambar.mjs "apel merah di latar putih polos" bahan/uji.png`

## Pakai
Buka folder ini di Claude Code, lalu ketik misalnya:

```
Buat video kolase tentang sejarah Jam Gadang Bukittinggi.
```

Claude akan: riset → naskah (minta persetujuanmu) → VO → `bahan/gambar.json` → `npm run gambar` → cek & potong gambar → komposisi baru → still per adegan → render `out/video.mp4` → `out/sampul.jpg` + `out/caption.txt`.

Perintah manual: `npm run studio` (pratinjau), `npm run render`, `npm run gambar`, `npm run cek`.

## Jadwalkan otomatis ke IG + TikTok
1. Pasang ekstensi **Claude in Chrome**, hubungkan ke Claude Code.
2. Di Chrome, login ke business.facebook.com dan tiktok.com/tiktokstudio (login & 2FA kamu sendiri).
3. Ketik ke Claude:

```
Jadwalkan out/video.mp4 ke Instagram @akunku dan TikTok, Kamis 20 Nov jam 20.30 WIB. Pakai caption out/caption.txt dan sampul out/sampul.jpg. Nyalakan label AI di TikTok. Tunjukkan ringkasannya dulu sebelum menjadwalkan.
```

Claude mengikuti skill `jadwalkan-posting`: konfirmasi dulu, pilih **Jadwal** (bukan Bagikan), lalu memverifikasi di daftar terjadwal.

## Tanpa Gemini API
Buat gambar sendiri di gemini.google.com memakai prompt dari `bahan/gambar.json`, simpan ke `bahan/<nama>.png`, lalu minta Claude melanjutkan dari langkah potong.

## Catatan
- Fakta wajib bersumber; cerita populer ditandai "konon". Gambar AI diberi label "ilustrasi AI".
- Tidak berafiliasi dengan Vox Media; nama/logo Vox tidak dipakai.
- Gaya: grafik 12–15 fps, transisi kamera+blur, latar tekstur berganti, kertas sobek, label potongan, panah tangan.
