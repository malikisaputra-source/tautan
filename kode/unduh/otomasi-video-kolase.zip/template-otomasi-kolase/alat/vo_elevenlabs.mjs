#!/usr/bin/env node
// (Opsional) Buat VO dari naskah lewat ElevenLabs API milikmu, lengkap dengan waktu tiap kata.
// Template oleh Maliki Saputra (@malikisaputra) — https://malikisaputra.biz.id · Lisensi Nonkomersial Maliki Studio 1.0
//
// Pakai: node alat/vo_elevenlabs.mjs naskah.txt
//   → public/vo.mp3 + src/waktu.json (teks kecil di tengah layar ikut kata yang diucapkan)
// .env: ELEVENLABS_API_KEY=...  ELEVENLABS_VOICE_ID=... (suara milikmu sendiri / pustaka ElevenLabs)
// Tanpa ElevenLabs: rekam suaramu sendiri lalu pakai alat/waktu_kira.mjs.
import fs from "node:fs";
import path from "node:path";

const akar = path.resolve(path.dirname(new URL(import.meta.url).pathname), "..");
const env = path.join(akar, ".env");
if (fs.existsSync(env)) for (const b of fs.readFileSync(env, "utf8").split("\n")) {
  const m = b.match(/^\s*([A-Z0-9_]+)\s*=\s*(.*)\s*$/); if (m && !process.env[m[1]]) process.env[m[1]] = m[2].replace(/^["']|["']$/g, "");
}
const KUNCI = process.env.ELEVENLABS_API_KEY, SUARA = process.env.ELEVENLABS_VOICE_ID;
if (!KUNCI || !SUARA) { console.error("Isi ELEVENLABS_API_KEY dan ELEVENLABS_VOICE_ID di .env"); process.exit(1); }
const naskah = fs.readFileSync(process.argv[2] || "naskah.txt", "utf8").trim();
const kalimat = naskah.split("\n").map((s) => s.trim()).filter(Boolean);

const r = await fetch(`https://api.elevenlabs.io/v1/text-to-speech/${SUARA}/with-timestamps`, {
  method: "POST",
  headers: { "xi-api-key": KUNCI, "Content-Type": "application/json" },
  body: JSON.stringify({ text: kalimat.join("\n"), model_id: process.env.ELEVENLABS_MODEL || "eleven_multilingual_v2" }),
});
if (!r.ok) { console.error(`ElevenLabs ${r.status}: ${await r.text()}`); process.exit(1); }
const j = await r.json();
fs.writeFileSync(path.join(akar, "public/vo.mp3"), Buffer.from(j.audio_base64, "base64"));

// huruf → kata → baris (maks 4 kata per potongan teks)
const al = j.alignment, kata = [];
let k = "", t0 = null;
al.characters.forEach((c, i) => {
  if (/\s/.test(c)) { if (k) kata.push({ k, t: t0, t1: al.character_end_times_seconds[i - 1] }); k = ""; t0 = null; }
  else { if (t0 === null) t0 = al.character_start_times_seconds[i]; k += c; }
});
if (k) kata.push({ k, t: t0, t1: al.character_end_times_seconds.at(-1) });
const sub = [];
for (let i = 0; i < kata.length; i += 4) {
  const g = kata.slice(i, i + 4);
  sub.push({ t0: g[0].t, t1: g.at(-1).t1, teks: g.map((x) => x.k).join(" "), kata: g.map((x) => ({ k: x.k, t: x.t })) });
}
const durasi = al.character_end_times_seconds.at(-1) + 0.3;
fs.writeFileSync(path.join(akar, "src/waktu.json"), JSON.stringify({ durasi, sub }));
console.log(`✓ public/vo.mp3 (${durasi.toFixed(1)} dtk) + src/waktu.json (${sub.length} potongan)`);
// awal tiap kalimat, untuk mengisi nilai t adegan
let idx = 0;
for (const s of kalimat) {
  const n = s.split(/\s+/).length; console.log(`  ${kata[idx]?.t?.toFixed(2).padStart(6)} dtk  ${s.slice(0, 60)}`); idx += n;
}
