# Pembukuan · Pencocokan Catatan Kasir vs Buku
Disusun oleh Hendra (Lantai 2, Pembukuan) · 12 November 2026
Sumber: `data/transaksi.csv` (data fiktif)

## Ringkasan
- Total transaksi diperiksa: 6
- Cocok: 4 (T01, T02, T04, T06)
- Berbeda: 2 (T03, T05), perlu dicek manusia

## Transaksi yang berbeda (perlu dicek)
- **T03 · Apotek · penjualan**
  - Catatan kasir: 10 strip parasetamol
  - Catatan buku: 8 strip parasetamol
  - Selisih: 2 strip (kasir lebih banyak)
- **T05 · Gudang · keluar**
  - Catatan kasir: 210 kg cabai
  - Catatan buku: 200 kg cabai
  - Selisih: 10 kg (kasir lebih banyak)

## Transaksi yang cocok
- T01 · Sembako · penjualan: 24 karung beras
- T02 · Sembako · penjualan: 31 botol minyak
- T04 · Simpan pinjam · angsuran: P03 diterima
- T06 · Klinik · kunjungan: 21 pasien

## Menunggu keputusan manusia
- Petugas mengecek T03 dan T05 ke bukti fisik (nota/struk, stok) untuk menentukan catatan mana yang benar.
- Koreksi buku hanya dilakukan setelah ada keputusan pengurus. Saya tidak mengubah data apa pun.
