# Proyek video kolase (Remotion)

Template oleh Maliki Saputra (@malikisaputra) — https://malikisaputra.biz.id. Lisensi Nonkomersial Maliki Studio 1.0
(`LICENSE`): boleh untuk diri sendiri/usaha sendiri, wajib kredit, dilarang dijual ulang atau dijadikan jasa berbayar.

- Saat pengguna minta video dari suatu topik, pakai skill **buat-video-kolase** (`.claude/skills/buat-video-kolase/SKILL.md`).
- Gambar dibuat lewat Gemini API milik pengguna (`alat/gemini_gambar.mjs`, kunci di `.env`). Jangan menulis kunci API ke file lain atau ke chat.
- Bahasa di layar dan naskah: Bahasa Indonesia.
- Posting/jadwal hanya lewat skill **jadwalkan-posting** dan hanya setelah pengguna menjawab "ya" untuk akun, tanggal, dan jam itu. Jangan pernah klik "Bagikan"/"Post now".
- Perintah: `npm run studio` (pratinjau), `npm run cek` (TypeScript), `npm run gambar` (buat gambar dari `bahan/gambar.json`).
