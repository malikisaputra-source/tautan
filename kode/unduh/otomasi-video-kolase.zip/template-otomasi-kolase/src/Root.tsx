import React from "react";
import { Composition } from "remotion";
import { KolaseGedungSate, DURASI_KOLASE } from "./KolaseGedungSate";

export const Root: React.FC = () => (
  <Composition id="KolaseGedungSate" component={KolaseGedungSate} durationInFrames={DURASI_KOLASE} fps={30} width={1080} height={1920} />
);
