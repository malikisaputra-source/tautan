# Penjualan Gerai Sembako · 12 November 2026

Sumber: `data/penjualan-sembako.csv`

## Ringkasan
- Jumlah jenis produk terjual: **8 jenis**

## 3 Produk Terlaris (berdasarkan angka jumlah)
1. Mi instan: 65 bungkus
2. Telur: 42 kg
3. Kopi sachet: 40 renceng

Catatan: satuan tiap produk berbeda (bungkus, kg, renceng), jadi urutan di atas hanya membandingkan angka jumlah apa adanya.

## Rincian Semua Produk
- Mi instan: 65 bungkus
- Telur: 42 kg
- Kopi sachet: 40 renceng
- Minyak goreng 1 L: 31 botol
- Beras 5 kg: 24 karung
- Gula pasir 1 kg: 18 bungkus
- Tepung terigu 1 kg: 9 bungkus
- Garam: 7 bungkus
