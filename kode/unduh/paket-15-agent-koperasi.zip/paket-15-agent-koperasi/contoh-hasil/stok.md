# Stok Sembako di Bawah Batas Minimum

Petugas: Bayu (Lantai 1, Stok Sembako)
Tanggal: 12 November 2026
Sumber: `data/stok-sembako.csv`

## Barang di bawah batas minimum (4 dari 8 produk)
- **Telur**: stok 10 kg, minimum 25 kg, kurang 15 kg. Usulan belanja: **15 kg**
- **Beras 5 kg**: stok 12 karung, minimum 20 karung, kurang 8 karung. Usulan belanja: **8 karung**
- **Gula pasir 1 kg**: stok 8 bungkus, minimum 15 bungkus, kurang 7 bungkus. Usulan belanja: **7 bungkus**
- **Kopi sachet**: stok 15 renceng, minimum 20 renceng, kurang 5 renceng. Usulan belanja: **5 renceng**

Usulan belanja = batas_minimum dikurangi stok, supaya stok kembali tepat ke batas minimum.

## Stok aman (di atas batas minimum)
- Minyak goreng 1 L: 45 botol (minimum 30)
- Tepung terigu 1 kg: 22 bungkus (minimum 10)
- Mi instan: 120 bungkus (minimum 60)
- Garam: 30 bungkus (minimum 10)

## Menunggu keputusan pengurus
- Persetujuan belanja ulang untuk 4 produk di atas (jumlah, pemasok, dan jadwal belanja belum ada di data)
