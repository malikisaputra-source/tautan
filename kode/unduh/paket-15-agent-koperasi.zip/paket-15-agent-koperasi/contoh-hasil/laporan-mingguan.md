# Laporan Mingguan · Koperasi Merah Putih Desa Sukamaju (fiktif)
Per 12 November 2026 · disusun oleh Doni (Lantai 3, Laporan)
Sumber: 13 file di `hasil/laporan/*.json` (gabungan di `hasil/laporan.json`). Laporan ketua belum ada karena ketua menyusul setelah rapat ini.

## Lantai 1 · Layanan anggota
- **Sembako (penjualan):** 8 jenis produk terjual. Terlaris: Mi instan 65 bungkus, Telur 42 kg, Kopi sachet 40 renceng.
- **Stok:** 4 dari 8 produk di bawah batas minimum.
  - Telur 10 kg (min 25), Beras 5 kg 12 karung (min 20), Gula pasir 1 kg 8 bungkus (min 15), Kopi sachet 15 renceng (min 20).
  - Usulan belanja: Telur 15 kg, Beras 8 karung, Gula 7 bungkus, Kopi 5 renceng (menunggu persetujuan).
- **Gudang:** 4 komoditas. Cabai merah keluar 210 kg, masuk 150 kg, sisa 90 kg.
  - Suhu cold storage di atas batas aman 0-5 °C: 6.2 °C (12:00) dan 5.4 °C (16:00), normal lagi 4.3 °C (20:00).
- **Logistik:** 7 antaran ke 4 RT (RT 01: 2, RT 02: 1, RT 03: 2, RT 05: 2). Jadwal, jam, dan petugas antar belum ada.
- **CS:** 6 pesan WA masuk, 6 draf balasan (0 terkirim). 1 keluhan: telur pecah 3 butir (Bu Inah, A03).

## Lantai 2 · Keuangan & kesehatan
- **Simpan pinjam:** 2 pengajuan baru (P01 Pak Darto, P02 Bu Neni) menunggu verifikasi, belum disetujui.
  - Jatuh tempo: P03 Pak Ujang 15 Nov, P04 Bu Sumi 17 Nov. Terlambat: P05 Pak Asep sejak 5 Nov.
- **Anggota:** 9 orang (7 aktif, 2 baru). Iuran wajib bulan ini sudah masuk 4 orang, belum 5 orang.
  - Belum: Bu Inah, Bu Lilis, Pak Asep (aktif), Pak Rudi, Bu Yati (baru).
- **Klinik:** 21 kunjungan. Batuk pilek 9, demam 6, kontrol darah tinggi 4, luka ringan 2. Dokter: Senin, Rabu, Jumat 08.00-12.00.
- **Apotek:** 3 dari 6 obat di bawah minimum, 3 obat kedaluwarsa dalam 60 hari.
  - Salep luka kedaluwarsa 30 Nov 2026 (stok 12).
  - Antasida tablet stok 15 (min 50), kedaluwarsa 20 Des 2026.
  - Amoksisilin 500 mg stok 30 (min 40), kedaluwarsa 30 Des 2026.
  - Parasetamol 500 mg stok 40 (min 100).
- **Pembukuan:** 6 transaksi dicek, 4 cocok, 2 berbeda.
  - T03 Apotek: kasir 10 strip parasetamol, buku 8 strip.
  - T05 Gudang: kasir 210 kg cabai, buku 200 kg.

## Lantai 3 · Pengurus & pengembangan
- **Harga (indeks, minggu lalu = 100):** Jagung +9%, Gabah +4%, Bawang merah 0%, Cabai merah -13%.
- **Konten:** 1 draf pengumuman WA + 3 caption medsos (belum dikirim). Isi: promo mi instan beli 10 gratis 1, minyak goreng 1 L stok banyak (14-20 Nov), senam sehat & cek tensi gratis Sabtu 15 Nov 07.00.
- **Desain:** poster A4 tegak di `hasil/poster.html`, isi sama dengan promo (belum dicetak/disebar).

## Temuan lintas lantai
- **Cabai merah:** keluar 210 kg di gudang sama dengan catatan kasir T05; buku mencatat 200 kg. Selisih 10 kg perlu dicek bukti fisik.
- **Pak Asep (M006):** angsuran P05 terlambat, iuran wajib belum masuk, dan bertanya syarat daftar anggota padahal sudah aktif.
- **Bu Inah (M003):** keluhan telur pecah dan iuran wajib belum masuk.
- **Telur dan beras:** stok di bawah minimum, sementara ada pesanan beras (Bu Sumi) dan permintaan ganti telur.
- **Antasida tablet:** stok rendah dan segera kedaluwarsa; ada pertanyaan obat maag dari Pak Ujang (diteruskan ke petugas apotek/klinik, tanpa saran obat).
- **Parasetamol:** stok di bawah minimum dan ada selisih catatan T03.
- **Promo:** klaim "stok banyak" minyak goreng 1 L sesuai data stok (45 botol, min 30). Mi instan 120 bungkus (min 60).

## Mendesak
1. Pengumuman WA, caption, dan poster perlu disetujui paling lambat 13 Nov (promo mulai 14 Nov, senam 15 Nov).
2. Suhu cold storage sempat di atas batas aman pada 12:00-16:00.
3. Salep luka kedaluwarsa 30 Nov 2026.
4. Angsuran P05 terlambat sejak 5 Nov; P03 jatuh tempo 15 Nov, P04 jatuh tempo 17 Nov.
5. Stok Telur, Beras 5 kg, Gula pasir 1 kg di bawah minimum.
6. Stok Antasida, Amoksisilin, Parasetamol di bawah minimum.
7. 2 selisih catatan kasir vs buku (T03, T05).
8. 3 anggota aktif belum bayar iuran wajib.

## Menunggu keputusan pengurus
- Belanja ulang sembako (Telur, Beras, Gula, Kopi) dan pengadaan ulang obat (Parasetamol, Antasida, Amoksisilin).
- Penanganan obat yang segera kedaluwarsa (Salep luka, Antasida, Amoksisilin).
- Pemeriksaan barang di cold storage, tindak lanjut stok cabai merah.
- Verifikasi pengajuan pinjaman P01 dan P02; arahan untuk angsuran terlambat P05.
- Tindak lanjut 5 anggota belum bayar iuran; apakah anggota baru wajib iuran di bulan pendaftaran.
- Penggantian telur pecah Bu Inah; jadwal antar pesanan Bu Sumi (cek apakah sama dengan A01).
- Jadwal, jam, dan petugas antar.
- Info jam buka dan syarat simpan pinjam, serta syarat daftar anggota (belum ada di data).
- Persetujuan pengumuman, caption, dan poster; syarat promo mi instan; petugas cek tensi.
- Penyesuaian harga beli/jual Jagung, Gabah, Cabai merah.
- Koreksi buku setelah pengecekan T03 dan T05.
- Tindak lanjut banyaknya kunjungan batuk pilek (keputusan medis tetap di dokter).
- Cara menghitung peringkat produk terlaris (satuan berbeda).
