# Perubahan Harga Hasil Tani Mingguan

Sumber: `data/harga-mingguan.csv` (indeks, minggu lalu = 100). Disusun 12 November 2026 oleh Raka (Lantai 3, Riset Harga).

## Urutan dari naik terbesar ke turun terbesar
1. Jagung: indeks 100 → 109, **naik 9%**
2. Gabah: indeks 100 → 104, **naik 4%**
3. Bawang merah: indeks 100 → 100, **tetap (0%)**
4. Cabai merah: indeks 100 → 87, **turun 13%**

## Catatan
- Kenaikan terbesar: Jagung (+9%).
- Penurunan terbesar: Cabai merah (-13%).
- Data berupa indeks, bukan harga rupiah. Tidak ada harga jual/beli baru yang ditetapkan di sini.

## Menunggu keputusan pengurus
- Apakah perlu menyesuaikan harga beli/jual koperasi untuk Jagung, Gabah, dan Cabai merah.
