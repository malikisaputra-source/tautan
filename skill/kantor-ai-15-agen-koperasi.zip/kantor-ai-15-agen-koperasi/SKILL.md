---
name: kantor-ai-15-agen-koperasi
description: Sesuaikan paket 15 AI agent koperasi desa + Kantor AI 3D merah-putih 3 lantai (contoh fiktif "Koperasi Desa Merah Putih Sukamaju") untuk koperasi pengguna, jalankan agentnya per lantai, lalu buka kantornya. Pakai saat diminta "kantor AI 15 agen", "15 agent koperasi", "kantor koperasi 3 lantai", atau menyesuaikan paket 15 agent koperasi.
---

# Kantor AI 15 Agen Koperasi (3 lantai)

Tujuan: dalam satu sesi, pengguna punya 15 agent yang nama, unit usaha, dan datanya sesuai koperasinya sendiri, dan
kantor 3D merah-putih 3 lantai yang menampilkan laporan mereka di browser.

## 0. Tanya dulu (maksimal 4 pertanyaan, sekaligus)
1. Nama koperasi dan desanya.
2. Unit usaha yang benar-benar ada (gerai sembako, simpan pinjam, klinik, apotek, gudang/cold storage, logistik).
3. Nama untuk 15 agent (boleh "terserah", pakai nama bawaan).
4. Data apa yang dia punya. Yang tidak ada, pakai data contoh dulu.

Kalau pengguna bilang "terserah", pakai struktur bawaan di bawah dan lanjut.

## 1. Siapkan proyek
Unduh paket "15 AI Agent Koperasi Desa + Kantor 3D 3 Lantai" dari malikisaputra.biz.id (Source Code → AI Agent),
ekstrak, buka foldernya. Isi paket: `CLAUDE.md`/`AGENTS.md` (aturan + larangan), `.claude/agents/` (15 agent Claude Code),
`.opencode/agent/` (15 agent OpenCode), `LANGKAH.md`, `data/` (13 file), `contoh-hasil/`, `src/` (kantor 3D),
`BACA-DULU.txt`. Folder `.claude` tersembunyi di Mac: Cmd + Shift + titik di Finder.

## 2. Struktur bawaan (jangan tambah/kurangi agent tanpa diminta)
| Lantai | Agent (key · nama) | Tugas |
|---|---|---|
| 1 Layanan anggota | `sembako` Dina | rekap penjualan gerai sembako |
| 1 | `stok` Bayu | stok di bawah batas minimum + usulan belanja |
| 1 | `gudang` Pak Joko | stok hasil tani, suhu cold storage di luar batas |
| 1 | `logistik` Rina | jadwal antar per RT |
| 1 | `cs` Fajar | draf balasan WA (tidak mengirim apa pun) |
| 2 Keuangan & kesehatan | `simpanpinjam` Sari | rekap pengajuan & angsuran (TIDAK menyetujui pinjaman) |
| 2 | `anggota` Wati | anggota baru, iuran belum masuk |
| 2 | `klinik` Nadia | rekap kunjungan, jadwal dokter (TANPA diagnosis) |
| 2 | `apotek` Dimas | obat stok rendah & kedaluwarsa ≤60 hari (TIDAK meresepkan) |
| 2 | `pembukuan` Hendra | transaksi kasir vs buku yang berbeda |
| 3 Pengurus | `harga` Raka | perubahan harga hasil tani mingguan |
| 3 | `konten` Sekar | pengumuman grup WA + 3 caption |
| 3 | `desain` Lita | poster promo `hasil/poster.html` |
| 3 | `laporan` Doni | laporan mingguan per lantai + `hasil/laporan.json` |
| 3 | `ketua` Bu Rahma | 3–5 prioritas + daftar "perlu keputusan pengurus" |

## 3. Ubah ke koperasi pengguna
- `CLAUDE.md` dan `AGENTS.md`: ganti nama koperasi contoh. **LARANGAN wajib dipertahankan**: tidak menyetujui pinjaman,
  tidak mendiagnosis, tidak meresepkan obat, tidak mengirim pesan, tidak menambah janji/klaim, tanpa nominal uang,
  pakai path relatif.
- `.claude/agents/*.md` (dan `.opencode/agent/*.md` bila memakai OpenCode): ganti nama dan konteks. `name:` jangan diubah.
  Unit yang tidak ada: hapus agentnya, juga dari `LANGKAH.md` dan `AGEN` di `src/config.ts`.
- `data/`: ganti dengan data pengguna, format kolom sama. Jangan mengarang data yang tidak diberikan.
- `src/config.ts`: `KANTOR.nama` (papan nama 3D), `KANTOR.subjudul`, `nama`/`tugas` di `AGEN`. Key dan posisi meja biarkan.
- Jangan memakai logo resmi Kopdes Merah Putih. Kalau contoh, tetap beri label fiktif.

## 4. Jalankan per lantai (jangan 15 sekaligus)
Claude Code (paket Pro): buka folder, ketik `claude`, lalu satu perintah per tahap (lihat `LANGKAH.md`):
1. "Kerjakan Tahap 1 saja: panggil subagent sembako, stok, gudang, logistik, cs."
2. Tahap 2: simpanpinjam, anggota, klinik, apotek, pembukuan.
3. Tahap 3: harga, konten, desain.
4. Tahap 4: laporan, tunggu selesai, lalu ketua.
Setelah tiap tahap, cek file di `hasil/` ada dan angkanya cocok dengan `data/`.
OpenCode gratis juga bisa (`opencode`, agent di `.opencode/agent/`): cek model aktif dengan `opencode models`, ganti model
kalau macet. Di uji kami GLM 5.3 Flash gratis menyelesaikan 11 dari 15 sebelum kena batas waktu.

## 5. Cek & buka kantor
```bash
cp hasil/laporan.json src/laporan.json
npm install
npm test && npm run build
npm run dev   # ?timelapse=1 untuk satu hari dipercepat
```
Pastikan 15 agent muncul di 3 lantai, papan nama terbaca utuh, tiap agent punya gelembung laporan.
Rekam video (opsional): `npm run rekam -- kantor.mp4` (butuh Chrome + ffmpeg).

## Aturan
- AI hanya membuat draf. Pinjaman, pengobatan, dan pesan ke anggota tetap diputuskan pengurus.
- Jangan mengarang angka di luar `data/`. Jangan tulis nominal uang, nomor rekening, atau data pribadi.
- Kredit "Template oleh Maliki Saputra (@malikisaputra)" wajib dipertahankan. Tidak untuk diperjualbelikan.
- Selesai = 15 laporan ada di `hasil/`, `npm test` lulus, build sukses, dan kantor sudah dilihat di browser.
